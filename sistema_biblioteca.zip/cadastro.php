<?php
session_start();

if(!empty($_SESSION)){
if(!($_SESSION['user'] == null) && !($_SESSION['senha'] ==null)){
  header('location:./dashboard.php');
}
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</head>
<body>

<div class="container login-container">
            <div class="row">
                <div class="col-md-6 login-form-1">
                    <img src="https://img.freepik.com/fotos-premium/uma-imagem-com-um-fundo-desfocado-mostra-uma-estante-de-biblioteca-com-muitos-livros-nela_410516-43749.jpg" width="100%">
                </div>
                <div class="col-md-6 login-form-2">
                    <h3>Cadastre-se</h3>
                    <form method="POST" id="form" onsubmit="" action="./php/cadastrar_usuario.php" autocomplete="on">
                        <div class="form-group">
                            <input type="text" class="form-control" name="nome" placeholder="Seu Nome *" value="" required />
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-control" name="email" placeholder="Seu Email *" value="" required/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" id="senha" name="senha" minlength="8" placeholder="Sua Senha *" value="" />
                            <input type="password" class="form-control" id="confirme_senha" minlength="8" name="confirmesenha" onfocus="validarsenha()" placeholder="Confirmar Senha *" value="" />
                        </div>

                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="tipo" id="inlineRadio1" value="Aluno" required>
                            <label class="form-check-label" for="inlineRadio1">Aluno</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="tipo" id="inlineRadio2" value="Professor">
                            <label class="form-check-label" for="inlineRadio2">Professor</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="tipo" id="inlineRadio3" value="Outro">
                            <label class="form-check-label" for="inlineRadio3">Outros</label>
                          </div>

                        <div class="form-group">
                            <input type="submit" class="btnSubmit" name="cadastrar" value="Cadastrar" />
                        </div>
                        <div class="form-group" style="margin-top: 1.2rem;">
                            <a href="index.php" class="ForgetPwd" value="Login">Já tem conta?</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script >
        var senha = document.getElementById("senha")
        var confirme_senha = document.getElementById("confirme_senha");

        function validarsenha(){
            if(senha.value != confirme_senha.value) {
                confirme_senha.setCustomValidity("As senhas não conferem!");
            } else {
                confirme_senha.setCustomValidity('');
            }
            }
        senha.onchange = validarsenha;
        confirme_senha.onkeyup = validarsenha;  
        </script>
</body>
</html>