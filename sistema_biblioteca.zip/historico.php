<?php
include './php/verifica_login_ativo.php';
include './php/sql.php';
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set('America/Sao_Paulo');

$id = $_SESSION['id'];
 $tarefa03 = $conectdb->query("SELECT * FROM usuarios_biblioteca WHERE id='$id'");
    $user_result3 = $tarefa03->fetch();
   if ($user_result3> 0) {
    $nome = $user_result3['nome'];
    $email = $user_result3['email'];
    $tipo = $user_result3['tipo'];
    $nivel = $user_result3['nivel'];
    //$foto = $user_result3['foto_url'];
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/css.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="http://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/update.js" type="text/javascript"></script>
    <title>Biblioteca FMP ADS</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="dashboard.php">Biblioteca FMP ADS</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown" style="justify-content: flex-end;">
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   <?php echo $_SESSION['nome']; ?>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
                  </svg>
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="dados_pessoais.php">Dados Pessoais</a></li>
                  <?php
                  if($_SESSION['nivel'] === 'administrador') {
                  echo '<li><a class="dropdown-item" href="publicar_livro.php">Publicar</a></li>'; 
                  }
                  ?>
                  <li><a class="dropdown-item" href="historico.php">Histórico</a></li>
                  <li><a class="dropdown-item" href="./php/sair.php?sair=sim">Sair</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card" style="margin-top: 1rem;">
                    <div class="card-header" style="display: flex; justify-content: center;">
                      <h5 class="card-title"> Histórico de Acesso:</h5>
                    </div>
                    <div class="card-body">
                                            <table class="table">
                    <thead>
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">Livro</th>
                        <th scope="col">Data de Acesso</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    try{
                        $selectdb_hist = $conectdb -> prepare("SELECT * FROM historico_biblioteca WHERE id_user ='$id' ORDER BY data_acesso DESC");
                        $selectdb_hist -> execute();
                        $retorno_hist = $selectdb_hist -> fetchAll(PDO::FETCH_ASSOC);
                        $i = 0;
                      foreach ($retorno_hist as $historico) {
                        $i = $i+1;
                        $_cod_livro = $historico['id_livro'];
                        $selectdb_livro = $conectdb -> prepare("SELECT * FROM livros WHERE cod_livro ='$_cod_livro'");
                        $selectdb_livro -> execute();
                        $retorno_livro = $selectdb_livro -> fetch(PDO::FETCH_ASSOC);
                        if(!empty($retorno_livro)){ //se apagar livro não mostrar historico
                        
                        
                        echo  '
                        <tr>
                        <th scope="row">'.$i.'</th>
                        <td><a href="detalhes_livros.php?cod_livro='.$_cod_livro.'" class="link-secondary link-offset-2 link-underline-opacity-25 link-underline-opacity-100-hover">'.$retorno_livro['titulo'].'</a></td>
                        <td>'.date('d/m/Y H:i:s', strtotime($historico['data_acesso'])).'</td>
                        </tr>';
                        
                        }
                         $data_atual= date('d-m-Y H:i:s');

                      //autodelete a cada 7 dias
                      //$tarefaMNT7 = $conectdb->query("DELETE FROM historico_biblioteca WHERE data_acesso+ INTERVAL 7 DAY < '$data_atual'");
                      //autodelete
                      }
                     
                    }catch(e){}

                      ?>
                    </tbody>
                    </table>
                        </i>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <script type="text/javascript" src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="http://assets.locaweb.com.br/locastyle/3.10.1/javascripts/locastyle.js" type="text/javascript"></script>
</body>
</html>