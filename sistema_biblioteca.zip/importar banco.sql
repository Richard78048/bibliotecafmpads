-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 24/03/2024 às 16:48
-- Versão do servidor: 10.3.39-MariaDB-cll-lve
-- Versão do PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cxlsnvlf_users`
--
--
-- Estrutura para tabela `comentarios_livros`
--

CREATE TABLE `comentarios_livros` (
  `cod_coment` int(30) NOT NULL,
  `cod_livro` int(11) NOT NULL,
  `comentario` varchar(300) NOT NULL,
  `id_user` int(11) NOT NULL,
  `stars` tinyint(1) NOT NULL,
  `data_publicacao` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `comentarios_livros`
--

INSERT INTO `comentarios_livros` (`cod_coment`, `cod_livro`, `comentario`, `id_user`, `stars`, `data_publicacao`) VALUES
(18, 3, 'Ã“timo ', 14, 5, '2024-03-15 15:53:11'),
(17, 2, 'esse livro Ã© excelente todo homem deveria ler.', 12, 5, '2024-03-15 14:21:59'),
(13, 6, 'leitura muito dificil', 13, 1, '2024-03-14 20:10:59'),
(14, 6, 'bacana mais precisa melhorar', 12, 4, '2024-03-14 20:27:06'),
(15, 4, 'boa para comeÃ§ar a entender sobre economia empresarial', 12, 5, '2024-03-15 11:52:54'),
(16, 9, 'conteÃºdo precisa atualizaÃ§Ã£o', 12, 3, '2024-03-15 11:54:05'),
(19, 1, 'Legal', 14, 4, '2024-03-15 15:53:34'),
(20, 8, 'Literatura henriquece a alma', 14, 4, '2024-03-15 15:54:13'),
(21, 10, 'Curso para docentes', 14, 5, '2024-03-15 15:54:33'),
(22, 7, 'NÃ£o gostei', 14, 2, '2024-03-15 15:55:11'),
(23, 5, 'Ã“tima ', 14, 3, '2024-03-15 15:55:35'),
(24, 12, 'Muito bom', 12, 5, '2024-03-19 08:10:55');

-- --------------------------------------------------------
--
-- Estrutura para tabela `historico_biblioteca`
--

CREATE TABLE `historico_biblioteca` (
  `id_hist` bigint(60) NOT NULL,
  `data_acesso` datetime NOT NULL,
  `id_livro` int(15) NOT NULL,
  `id_user` int(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `historico_biblioteca`
--

INSERT INTO `historico_biblioteca` (`id_hist`, `data_acesso`, `id_livro`, `id_user`) VALUES
(77, '2024-03-27 15:58:31', 1, 14),
(76, '2024-03-15 15:57:47', 8, 14),
(75, '2024-03-15 15:57:02', 10, 14),
(74, '2024-03-15 15:56:35', 7, 14),
(73, '2024-03-15 15:56:24', 5, 14),
(72, '2024-03-15 15:56:01', 5, 14),
(71, '2024-03-15 15:55:43', 2, 14),
(70, '2024-03-15 15:55:38', 5, 14),
(69, '2024-03-15 15:55:35', 5, 14),
(68, '2024-03-15 15:55:24', 5, 14),
(67, '2024-03-15 15:55:11', 7, 14),
(66, '2024-03-15 15:54:52', 7, 14),
(65, '2024-03-15 15:54:36', 10, 14),
(64, '2024-03-15 15:54:33', 10, 14),
(63, '2024-03-15 15:54:24', 10, 14),
(62, '2024-03-15 15:54:19', 8, 14),
(61, '2024-03-15 15:54:13', 8, 14),
(60, '2024-03-15 15:53:44', 8, 14),
(59, '2024-03-15 15:53:38', 1, 14),
(58, '2024-03-15 15:53:35', 1, 14),
(57, '2024-03-15 15:53:26', 1, 14),
(56, '2024-03-28 15:53:19', 3, 14),
(55, '2024-03-15 15:53:13', 3, 14),
(54, '2024-03-15 15:53:11', 3, 14),
(53, '2024-03-25 15:53:01', 3, 14),
(52, '2024-03-15 15:52:56', 9, 14),
(51, '2024-03-15 15:52:47', 4, 14),
(50, '2024-03-15 15:52:40', 6, 14),
(78, '2024-03-15 15:58:51', 3, 14),
(79, '2024-03-15 16:00:07', 6, 14),
(80, '2024-03-15 16:00:24', 4, 14),
(81, '2024-03-15 16:00:46', 1, 14),
(82, '2024-03-15 16:00:59', 8, 14),
(83, '2024-03-15 16:01:30', 8, 14),
(84, '2024-03-15 16:01:47', 8, 14),
(85, '2024-03-15 16:01:55', 7, 14),
(267, '2024-03-24 12:39:50', 37, 12),
(269, '2024-03-24 12:40:31', 38, 12),
(272, '2024-03-24 12:44:10', 38, 12),
(275, '2024-03-24 12:53:21', 39, 12),
(99, '2024-03-19 08:01:53', 22, 12),
(100, '2024-03-19 08:09:56', 12, 12),
(101, '2024-03-19 08:10:55', 12, 12),
(102, '2024-03-19 08:11:40', 12, 12),
(103, '2024-03-19 14:44:11', 12, 12),
(105, '2024-03-20 07:33:31', 12, 12),
(106, '2024-03-20 08:05:53', 12, 12),
(107, '2024-03-20 08:07:06', 12, 12),
(108, '2024-03-20 08:07:56', 12, 12),
(109, '2024-03-20 15:55:50', 12, 12),
(110, '2024-03-20 16:16:35', 12, 12),
(111, '2024-03-20 16:16:55', 12, 12),
(112, '2024-03-20 16:17:12', 12, 12),
(113, '2024-03-20 16:17:59', 12, 12),
(114, '2024-03-20 16:18:15', 12, 12),
(115, '2024-03-20 16:18:50', 12, 12),
(116, '2024-03-20 16:19:03', 12, 12),
(117, '2024-03-20 16:21:29', 12, 12),
(118, '2024-03-20 16:22:34', 12, 12),
(119, '2024-03-20 16:23:15', 12, 12),
(120, '2024-03-20 16:28:16', 12, 12),
(121, '2024-03-20 16:41:20', 12, 12),
(290, '2024-03-24 14:27:46', 61, 12),
(289, '2024-03-24 13:57:16', 52, 12),
(288, '2024-03-24 13:52:58', 51, 12),
(287, '2024-03-24 13:49:08', 50, 12),
(286, '2024-03-24 13:46:08', 49, 12),
(285, '2024-03-24 13:35:54', 45, 12),
(284, '2024-03-24 13:28:58', 44, 12),
(283, '2024-03-24 13:26:50', 44, 12),
(282, '2024-03-24 13:19:36', 42, 12),
(281, '2024-03-24 13:19:19', 42, 12),
(280, '2024-03-24 13:17:43', 42, 12),
(279, '2024-03-24 13:17:26', 43, 12),
(278, '2024-03-24 13:11:35', 42, 12),
(138, '2024-03-20 18:01:04', 1, 12),
(139, '2024-03-20 18:01:20', 1, 12),
(140, '2024-03-20 18:01:37', 1, 12),
(141, '2024-03-20 18:03:42', 1, 12),
(142, '2024-03-20 18:04:16', 1, 12),
(143, '2024-03-20 18:05:24', 1, 12),
(144, '2024-03-20 18:12:57', 1, 12),
(145, '2024-03-20 19:01:56', 1, 12),
(146, '2024-03-20 19:03:11', 1, 12),
(147, '2024-03-20 19:03:13', 1, 12),
(148, '2024-03-20 19:08:49', 1, 12),
(149, '2024-03-20 19:22:32', 1, 12),
(150, '2024-03-20 19:23:10', 1, 12),
(151, '2024-03-20 19:23:26', 1, 12),
(152, '2024-03-20 19:24:39', 1, 12),
(153, '2024-03-20 19:27:14', 1, 12),
(154, '2024-03-20 19:27:30', 1, 12),
(155, '2024-03-20 19:27:37', 1, 12),
(156, '2024-03-20 19:27:58', 1, 12),
(157, '2024-03-20 19:28:00', 1, 12),
(158, '2024-03-20 19:29:11', 1, 12),
(159, '2024-03-20 19:29:13', 1, 12),
(160, '2024-03-20 19:30:22', 12, 12),
(162, '2024-03-20 22:22:52', 22, 12),
(163, '2024-03-20 22:25:17', 1, 12),
(164, '2024-03-20 22:25:34', 1, 12),
(165, '2024-03-20 22:25:42', 1, 12),
(166, '2024-03-20 22:26:03', 1, 12),
(167, '2024-03-20 22:26:17', 1, 12),
(168, '2024-03-20 22:26:21', 1, 12),
(169, '2024-03-20 22:26:28', 1, 12),
(170, '2024-03-21 07:07:02', 12, 12),
(171, '2024-03-21 07:07:36', 12, 12),
(172, '2024-03-23 16:20:26', 12, 12),
(174, '2024-03-23 16:21:12', 12, 12),
(175, '2024-03-23 16:21:48', 12, 12),
(176, '2024-03-23 16:24:01', 1, 12),
(177, '2024-03-23 16:24:44', 12, 12),
(178, '2024-03-23 18:42:12', 12, 12),
(179, '2024-03-23 19:36:48', 12, 12),
(180, '2024-03-23 19:37:42', 12, 12),
(266, '2024-03-24 02:03:26', 13, 17),
(265, '2024-03-24 02:02:03', 12, 17),
(183, '2024-03-23 19:39:38', 25, 12),
(184, '2024-03-23 19:39:53', 1, 12),
(185, '2024-03-23 19:44:17', 1, 12),
(186, '2024-03-23 19:44:35', 1, 12),
(187, '2024-03-23 19:45:11', 1, 12),
(188, '2024-03-23 19:45:16', 1, 12),
(189, '2024-03-23 19:45:41', 1, 12),
(190, '2024-03-23 19:45:58', 12, 12),
(191, '2024-03-23 19:46:08', 25, 12),
(192, '2024-03-23 19:46:08', 25, 12),
(277, '2024-03-24 13:04:23', 41, 12),
(264, '2024-03-24 01:59:48', 12, 12),
(195, '2024-03-23 19:46:48', 1, 12),
(196, '2024-03-23 19:47:46', 1, 12),
(197, '2024-03-23 19:47:54', 1, 12),
(198, '2024-03-23 19:49:08', 1, 12),
(199, '2024-03-23 20:47:50', 11, 12),
(201, '2024-03-23 20:50:00', 11, 12),
(263, '2024-03-24 01:56:35', 12, 12),
(203, '2024-03-23 20:50:44', 12, 12),
(204, '2024-03-23 20:51:00', 13, 12),
(205, '2024-03-23 20:51:44', 14, 12),
(271, '2024-03-24 12:42:30', 12, 12),
(274, '2024-03-24 12:52:19', 39, 12),
(215, '2024-03-23 21:16:05', 12, 12),
(219, '2024-03-23 22:05:04', 12, 12),
(220, '2024-03-23 22:05:28', 11, 12),
(221, '2024-03-23 22:05:46', 13, 12),
(222, '2024-03-23 22:05:51', 14, 12),
(276, '2024-03-24 12:58:57', 40, 12),
(262, '2024-03-24 01:53:21', 4, 12),
(226, '2024-03-23 22:06:05', 21, 12),
(227, '2024-03-23 22:06:08', 28, 12),
(268, '2024-03-24 12:40:08', 38, 12),
(229, '2024-03-23 22:06:15', 17, 12),
(230, '2024-03-23 22:06:19', 16, 12),
(231, '2024-03-23 22:06:23', 22, 12),
(232, '2024-03-23 22:06:27', 30, 12),
(233, '2024-03-23 22:06:31', 18, 12),
(234, '2024-03-23 22:06:35', 15, 12),
(270, '2024-03-24 12:41:57', 38, 12),
(236, '2024-03-23 22:06:42', 27, 12),
(237, '2024-03-23 22:06:46', 20, 12),
(238, '2024-03-23 22:06:48', 24, 12),
(239, '2024-03-23 22:06:53', 24, 12),
(240, '2024-03-23 22:06:56', 29, 12),
(241, '2024-03-23 22:06:58', 1, 12),
(242, '2024-03-23 22:07:03', 26, 12),
(273, '2024-03-24 12:50:10', 39, 12),
(245, '2024-03-23 22:07:14', 25, 12),
(248, '2024-03-23 22:29:58', 1, 12),
(249, '2024-03-23 22:30:06', 1, 12),
(255, '2024-03-23 23:05:56', 31, 12),
(256, '2024-03-23 23:06:54', 31, 12),
(257, '2024-03-23 23:07:34', 31, 12),
(258, '2024-03-23 23:09:11', 31, 12),
(259, '2024-03-23 23:17:46', 32, 12),
(260, '2024-03-23 23:32:51', 36, 12),
(261, '2024-03-24 01:30:50', 12, 12);

-- --------------------------------------------------------

--
-- Estrutura para tabela `livros`
--

CREATE TABLE `livros` (
  `cod_livro` int(30) NOT NULL,
  `autor` varchar(50) NOT NULL,
  `genero` varchar(20) NOT NULL,
  `editora` varchar(40) NOT NULL,
  `titulo` varchar(100) NOT NULL,
  `descricao` varchar(5000) NOT NULL,
  `url_capa` varchar(200) NOT NULL,
  `url_arquivo` varchar(200) NOT NULL,
  `data_publicacao` date NOT NULL,
  `paginas` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `livros`
--

INSERT INTO `livros` (`cod_livro`, `autor`, `genero`, `editora`, `titulo`, `descricao`, `url_capa`, `url_arquivo`, `data_publicacao`, `paginas`) VALUES
(32, 'JosÃ© de Alencar', 'Literatura', 'Biblioteca Nacional', 'Iracema', ' obra-prima da literatura brasileira, escrita por JosÃ© de Alencar e publicada em 1865. Ambientada no perÃ­odo da colonizaÃ§Ã£o do Brasil, a histÃ³ria se passa no CearÃ¡, e Ã© centrada no amor impossÃ­vel entre Iracema, a virgem dos lÃ¡bios de mel e filha do pajÃ© da tribo Tabajara, e Martim, um portuguÃªs branco que se torna grande amigo dos indÃ­genas.\r\n\r\nO romance Ã© uma mescla de elementos histÃ³ricos, mitolÃ³gicos e romÃ¢nticos, marcado pela fusÃ£o entre a cultura indÃ­gena e a chegada dos colonizadores europeus. Iracema Ã© retratada como uma figura mÃ­tica e simbÃ³lica, representando a pureza, a beleza e a ligaÃ§Ã£o com a natureza selvagem da terra.\r\n\r\nA narrativa Ã© permeada por conflitos entre os povos indÃ­genas e os colonizadores, explorando temas como o choque de culturas, a busca pela identidade nacional e os desafios da colonizaÃ§Ã£o. Martim, o colonizador branco, Ã© apresentado como um herÃ³i idealizado, cujo amor por Iracema Ã© testado pelos conflitos entre sua lealdade aos colonizadores e sua amizade com os nativos.\r\n\r\nAlÃ©m do aspecto romÃ¢ntico, o livro tambÃ©m aborda questÃµes como a terra, a natureza, a liberdade e a guerra, refletindo sobre as relaÃ§Ãµes entre os diferentes grupos Ã©tnicos que habitavam o Brasil na Ã©poca.\r\n\r\n\"Iracema\" Ã© uma obra que exerceu grande influÃªncia na literatura brasileira, sendo considerada uma das principais representaÃ§Ãµes do indianismo, movimento literÃ¡rio que valorizava a cultura e a identidade nacional. AtravÃ©s de sua linguagem poÃ©tica e da descriÃ§Ã£o detalhada da paisagem e dos costumes indÃ­genas, JosÃ© de Alencar constrÃ³i um retrato vÃ­vido e emocionante do Brasil colonial.', 'https://www.baixelivros.com.br/media/2020/02/iracema.jpg', 'https://domainpublic.files.wordpress.com/2022/01/iracema.pdf', '2012-01-01', NULL),
(33, 'VÃ¡rios Autores', 'Ads', 'ESESP', 'Curso: Excel Total â€“ BÃ¡sico e AvanÃ§ado', 'O que vou aprender?\r\nInserir dados e organizar informaÃ§Ãµes na planilha â€“ salvar e editar dados â€“ aplicar formataÃ§Ãµes â€“ usar fÃ³rmulas e funÃ§Ãµes bÃ¡sicas para fazer cÃ¡lculos â€“ usar os recursos das guias: PÃ¡gina Inicial, inserir, layout e revisÃ£o â€“ fazer formataÃ§Ã£o condicional para destacar cÃ©lulas.', 'https://www.baixelivros.com.br/media/2021/02/excel-total.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_47dc52d9877343a2bca9c3d9ed723a70.pdf', '2018-01-01', NULL),
(2, 'Sun Tzu', 'Literatura', 'Chinatown', 'A Arte da Guerra: EdiÃ§Ã£o de luxo Almofadado', 'O que faz de um tratado militar, escrito por volta de 500 a.C., manter-se atual a ponto de ser publicado praticamente no mundo todo atÃ© os dias de hoje? VocÃª verÃ¡ que, em A arte da guerra, as estratÃ©gias transmitidas pelo general chinÃªs Sun Tzu carregam um profundo conhecimento da natureza humana. Elas transcendem os limites dos campos de batalha e alcanÃ§am o contexto das pequenas ou grandes lutas cotidianas, sejam em ambientes competitivos â€“ como os do mundo corporativo â€“ sejam nos desafios internos, em que temos de encarar nossas prÃ³prias dificuldades. Se vocÃª nÃ£o conhece a si mesmo nem o inimigo, sucumbirÃ¡ a todas as batalhas. Sun Tzu', 'https://editorapedaletra.com.br/media/catalog/product/cache/d51e17e3f97aa21e3ce0a3f7526ec2e9/a/r/arteguerra.png', 'https://www.jfpb.jus.br/arquivos/biblioteca/e-books/A_arte_da_guerra.pdf\"', '2024-03-08', NULL),
(3, 'Ciro BÃ¤chtold', 'AdministraÃ§Ã£o', 'IFP', 'Contabilidade BÃ¡sica', 'A contabilidade constitui um dos conhecimentos mais antigos de que se tem notÃ­cia. Surgiu da necessidade de controle das posses e riquezas, ou seja, do patrimÃ´nio. HÃ¡ a hipÃ³tese de que a contabilidade tenha surgido antes da escrita, dado a sua importÃ¢ncia para o homem', 'https://www.baixelivros.com.br/media/2019/05/contabilidade-basica.jpg', 'https://redeetec.mec.gov.br/images/stories/pdf/proeja/contabil_basica.pdf', '2011-01-01', NULL),
(4, 'VÃ¡rios', 'AdministraÃ§Ã£o', 'UFSC', 'IntroduÃ§Ã£o Ã  Economia', 'O estudo da Economia Ã© cativante e relevante para nossa vida diÃ¡ria e profissional. EntendÃª-lo nÃ£o requer segredos ou fÃ³rmulas mÃ¡gicas, mas sim disposiÃ§Ã£o, curiosidade, determinaÃ§Ã£o e interesse.', 'https://www.baixelivros.com.br/media/2024/01/introducao-economia.jpg', 'https://archivepublicdomain.com/files/2024/01/introducao-economia.pdf', '2009-01-01', NULL),
(5, 'Henrique Lana', 'AdministraÃ§Ã£o', 'EXPERTE', 'Bens Digitais â€“ Direito Patrimonial', 'Uma compreensÃ£o abrangente do Direito das SucessÃµes no contexto do patrimÃ´nio digital, explorando desafios legais, propondo soluÃ§Ãµes e incentivando o planejamento sucessÃ³rio. Redes sociais e as moedas digitais (bitcoin), para entender como esses bens sÃ£o tratados apÃ³s o falecimento.', 'https://www.baixelivros.com.br/media/2024/01/direito-patrimonial.jpg', 'https://domainpublic.files.wordpress.com/2024/01/o-direito-patrimonial-apos-o-falecimento-e-os-bens-digitais.pdf', '2023-01-01', NULL),
(6, 'Filipe Del Nero Grillo', 'Ads', 'Deconhecido', 'Aprendendo JavaScript', 'Por que aprender JavaScript?\r\nSe buscarmos na internet por respostas a esta pergunta, encontramos:\r\nâ€“ \"JavaScript Ã© a ferramenta que dÃ¡ acesso a um grande nÃºmero de truques e\r\nde funcionalidades avanÃ§adas que estÃ£o ao alcance de todos\".\r\nâ€“ \"JavaScript Ã© usada em milhÃµes de pÃ¡ginas Web com intuito de melhorar\r\ntodo projeto\"\r\nâ€“ \"Com JavaScript vocÃª pode deixar a sua pÃ¡gina muito mais legal!\"\r\nDe fato, concordamos que essas respostas falam verdade! Mas essa fama de\r\nser uma linguagem â€™leveâ€™, para fazer truques em pÃ¡ginas, faz com que muitas\r\npessoas pensem que JavaScript nÃ£o Ã© uma linguagem de programaÃ§Ã£o sÃ©ria.\r\nMuitos lembram dela como se fosse apenas uma extensÃ£o do HTML. A sigla\r\nDHTML (Dynamic HTML) Ã© uma das causadoras dessa impressÃ£o, porque sugere\r\nque Ã© um novo tipo de HTML e nÃ£o que Ã© usado JavaScript e HTML juntos.\r\nNa verdade, JavaScript Ã© uma linguagem de programaÃ§Ã£o de propÃ³sito geral,\r\ndinÃ¢mica e possui caracterÃ­sticas do paradigma de orientaÃ§Ã£o a objetos. Ela Ã©\r\ncapaz de realizar virtualmente qualquer tipo de aplicaÃ§Ã£o, e rodarÃ¡ no browser\r\ndo cliente.\r\nAtualmente, uma empresa que utiliza JavaScript em praticamente todos os\r\nseus aplicativos Ã© a Google Inc., como por exemplo: no site de busca Google Search1\r\n, no GMail2\r\n, no Google Maps3\r\n, entre outros. O que torna esses aplicativos\r\ntÃ£o populares Ã© a forma como sÃ£o interativos, e isso se deve em maior parte ao\r\nJavaScript.\r\nA linguagem JavaScript foi objeto de estudo do projeto de iniciaÃ§Ã£o cientÃ­fica\r\ndeste autor, e foi utilizada no desenvolvimento de um editor de diagramas online,\r\nvia Web, utilizando SVG (Scalable Vector Graphics) e JavaScript.\r\nComo resultado do estudo realizado, foi elaborado este documento visando\r\nservir de base inicial para que outros interessados possam ter um roteiro prÃ¡tico\r\npara prosseguir e se aprofundar em seus estudos.', 'https://upload.wikimedia.org/wikipedia/commons/thumb/9/99/Unofficial_JavaScript_logo_2.svg/1200px-Unofficial_JavaScript_logo_2.svg.png', 'https://repositorio.usp.br/directbitstream/4cd7f9b7-7144-40f4-bfd0-7a1d9a6bd748/nd_72.pdf', '2008-02-21', NULL),
(7, 'PlatÃ£o', 'Literatura', 'Independente', 'A RepÃºblica', 'Uma das mais importantes obras de PlatÃ£o, onde ele expÃµe suas idÃ©ias polÃ­ticas e filosÃ³ficas, junto a propostas estÃ©ticas, Ã©ticas, pedagÃ³gicas e jurÃ­dicas. â€˜A RepÃºblicaâ€™ combina um modelo de utopia social a uma teoria sobre a construÃ§Ã£o do conhecimento humano. No livro estÃ¡ contido tambÃ©m a famosa alegoria da caverna.', 'https://www.baixelivros.com.br/media/2018/12/a-republica.jpg', 'https://eniopadilha-com-br.usrfiles.com/ugd/5ca0e9_25f5954b7b7a4a76892d3650ec0cd36c.pdf', '2021-10-25', NULL),
(8, 'Machado de Assis', 'Literatura', 'EdiÃ§Ãµes CÃ¢mara', 'Dom Casmurro', 'Dom Casmurro, um dos romances mais conhecidos do autor, foi publicado pela primeira vez em 1900. Bentinho, Capitu e Escobar sÃ£o os protagonistas do enigmÃ¡tico triÃ¢ngulo amoroso criado por Machado de Assis e jÃ¡ fazem parte de nosso imaginÃ¡rio.', 'https://www.baixelivros.com.br/media/2018/12/domcasmurro.jpg', 'https://livraria-camara-leg.usrfiles.com/ugd/5ca0e9_77426ca451ec4f60b14af67f925f038e.pdf', '2019-01-01', NULL),
(9, 'Luiz Manoel Figueiredo', 'Ads', 'CEP/EB', 'IntroduÃ§Ã£o Ã  Criptografia ', 'AritmÃ©tica dos inteiros: nÃºmeros primos, algoritmo da divisÃ£o, mdc e mmc, algoritmo de Euclides. AritmÃ©tica modular: congruÃªncia mÃ³dulo, soma e produto de classes, inversa de uma classe mÃ³dulo n. (editado)', 'https://www.baixelivros.com.br/media/2022/04/introducao-a-criptografia.jpg', 'https://canal.cecierj.edu.br/012016/8139aa5685a51bc51dad153266f7064d.pdf', '2010-01-01', NULL),
(34, 'VÃ¡rios Autores', 'Outros', 'FDR', 'Curso: HistÃ³rias em Quadrinhos (HQ)', 'O curso tem como objetivo contribuir para a formaÃ§Ã£o e o fomento do debate de empreendedorismo entre os profissionais das cadeias criativa e produtiva das histÃ³rias em quadrinhos.', 'https://www.baixelivros.com.br/media/2020/12/historias-de-quadrinhos.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_7409071f696845778d14c0b6e4f9d2da.pdf', '2016-01-01', NULL),
(11, 'PlatÃ£o', 'Literatura', 'VirtualBooks', 'O Banquete', 'O Banquete Ã© um dos diÃ¡logos mais cÃ©lebres de PlatÃ£o (428-347 a.C.). Ambientado durante um jantar oferecido pelo poeta AgatÃ£o em Atenas, pÃµe em cena SÃ³crates, AristÃ³fanes e outros convivas enfrentando-se em uma competiÃ§Ã£o: cada um deve fazer um discurso de elogio Ã  figura de Eros, o deus do amor.', 'https://www.baixelivros.com.br/media/2019/01/o-banquete.jpg', 'https://web.archive.org/web/20201026221745/http://revistaliteraria.com.br/PlataoOBanquete.pdf', '2003-01-01', NULL),
(12, 'JÃºlio Verne', 'Literatura', 'EBC', 'A Volta ao Mundo em Oitenta Dias', 'ClÃ¡ssico da literatura juvenil, esta reediÃ§Ã£o comemora os 100 anos do autor JÃºlio Verne e conta a histÃ³ria de um inglÃªs, Phileas Fogg, que tinha uma vida regrada e solitÃ¡ria, mas com muito dinheiro e, devido a uma aposta com seus amigos de jogo, resolve dar a volta ao mundo em oitenta dias.\r\n\r\n', 'https://www.baixelivros.com.br/media/2019/03/volta-mundo-dias.jpg', 'https://memoria.ebc.com.br/sites/_portalebc2014/files/atoms/files/-a_volta_ao_mundo_em_80_dias_-_julio_verne.pdf', '1873-01-01', NULL),
(13, 'PlatÃ£o', 'Literatura', 'VirtualBooks', 'Apologia de SÃ³crates', 'O julgamento de SÃ³crates (469-399 a.C.) foi um dos fatos histÃ³ricos mais importantes da GrÃ©cia Antiga e atÃ© hoje inspira escritores, artistas e filÃ³sofos. Em 399 a.C., Atenas estava se recompondo apÃ³s a derrota para Esparta na Guerra do Peloponeso, tentando consolidar o ainda frÃ¡gil regime democrÃ¡tico.', 'https://www.baixelivros.com.br/media/2019/01/apologia-de-socrates.jpg', 'https://domainpublic.files.wordpress.com/2022/01/plataoapologia.pdf', '2003-01-01', NULL),
(14, 'Santo Agostinho', 'Literatura', 'CanÃ§Ã£o Nova', 'ConfissÃµes', 'Santo Agostinho sofreu as maiores angÃºstias e logrou as mais requintadas alegrias da vida, quando encontrou o norte de sua travessia. Escreveu ConfissÃµes, uma obra de mÃ­stica muito elevada, e, ao mesmo tempo, de profunda especulaÃ§Ã£o.\r\n\r\nHoje Ã©, sem dÃºvida, o livro mais lido de S. Agostinho e que mais fala Ã  atormentada alma dos pensadores, mÃ­sticos e homens de letras contemporÃ¢neas.\r\n\r\nObra de grande valor literÃ¡rio, sua originalidade estÃ¡ na capacidade de intuiÃ§Ã£o e ressonÃ¢ncia universal, atravÃ©s da qual Agostinho sente e exprime o drama de uma alma que se redime.\r\n\r\nSua finalidade Ã© confessar-se pecador e proclamar a soberana misericÃ³rdia de Deus. Sua grandeza nÃ£o consiste em ser filÃ³sofo ou literato, mas em ter escrito ConfissÃµes, como grande filÃ³sofo e literato que era. Sua grandeza nÃ£o consiste em ser filÃ³sofo ou literato, mas em ter escrito ConfissÃµes, como grande filÃ³sofo e literato que era.', 'https://www.baixelivros.com.br/media/2019/03/confissoes-1.jpg', 'https://img.cancaonova.com/noticias/pdf/277537_SantoAgostinho-Confissoes.pdf', '2007-01-01', NULL),
(15, 'Paulo Mattos', 'AdministraÃ§Ã£o', 'ENAP', 'Microeconomia', 'A Microeconomia, em sua formulaÃ§Ã£o padrÃ£o, com base nos desenvolvimentos do utilitarismo da economia neoclÃ¡ssica, constitui um corpo teÃ³rico o qual parte do entendimento do comportamento econÃ´mico individualizado dos agentes, tomados como racionais.', 'https://www.baixelivros.com.br/media/2022/04/microeconomia.jpg', 'https://domainpublic.files.wordpress.com/2022/04/microeconomia-compress.pdf', '2015-01-01', NULL),
(16, 'Pedro Salanek Filho', 'AdministraÃ§Ã£o', 'IFS', 'GestÃ£o Financeira para Eventos', 'O grande objetivo deste nosso mÃ³dulo Ã© produzir conhecimentos sÃ³lidos e que possam ser aplicados no dia a dia. Assuntos como orÃ§amentos, fluxo de caixa, gestÃ£o de custos, formaÃ§Ã£o de preÃ§os, entre outros, fazem parte do nosso mÃ³dulo.', 'https://www.baixelivros.com.br/media/2022/02/gestao-financeira-eventos.jpg', 'https://domainpublic.files.wordpress.com/2022/02/gestao-financeira-para-eventos.pdf', '2013-01-01', NULL),
(17, 'VÃ¡rios Autores', 'Ads', 'FundaÃ§Ã£o Padre Anchieta', 'EletrÃ´nica: Circuitos ElÃ©tricos (Vol. 1)', 'Este volume de EletrÃ´nica Ã© o primeiro de uma coleÃ§Ã£o elaborada especialmente pelo Centro Paula Souza e pela FundaÃ§Ã£o Padre Anchieta para levar aos alunos das Escolas TÃ©cnicas estaduais (Etecs) material didÃ¡tico padronizado, gratuito e de qualidade.', 'https://www.baixelivros.com.br/media/2021/03/eletronica-circuitos-eletricos.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_5384803342a54f019bea69e70f6534c3.pdf', '2011-01-01', NULL),
(18, 'VÃ¡rios Autores', 'Ads', ' e-Tec/IFPE', 'Curso: InformÃ¡tica BÃ¡sica', 'Nesse componente curricular abordaremos os fundamentos da informÃ¡tica, seus conceitos bÃ¡sicos e uma breve histÃ³ria e evoluÃ§Ã£o dos computadores ao longo dos tempos.', 'https://www.baixelivros.com.br/media/2021/01/informatica-basica.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_308ff8479c164b7e93661e4cf96fa260.pdf', '2014-01-01', NULL),
(19, 'VÃ¡rios Autores', 'Processos', 'DireÃ§Ã£o Concursos', 'RedaÃ§Ã£o CESPE â€“ 30 Temas', 'A DireÃ§Ã£o Concursos preparou um material de consulta para que vocÃª tenha uma perfeita noÃ§Ã£o de como a Banca CESPE cobra este tipo de exercÃ­cio. De posse deste histÃ³rico, vocÃª conseguirÃ¡ treinar e saber como Ã© o estilo do CESPE. O treino Ã© fundamental, por isso, selecionamos 30 temas.', 'https://www.baixelivros.com.br/media/2020/12/redacao-cespe.jpg', 'https://cdn.direcaoconcursos.com.br/uploads/2019/04/E-book-reda%C3%A7%C3%A3o-CESPE.pdf', '2019-01-01', NULL),
(20, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'SEBRAE-SP', 'Curso: Empreendedorismo â€“ OpÃ§Ã£o de Carreira', 'Neste e-book vocÃª terÃ¡ a oportunidade de saber o que Ã© empreendedorismo, conhecer o cenÃ¡rio nacional, descobrir qual Ã© o seu perfil, se vocÃª tem um comportamento empreendedor e o que pode fazer para ter um negÃ³cio de sucesso.', 'https://www.baixelivros.com.br/media/2020/06/curso-empreendorismo.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_59f401de40084635a1561c77603b63a4.pdf', '2016-01-01', NULL),
(21, 'Fabiane AraÃºjo', 'Ads', 'e-Tec Brasil', 'Curso: InglÃªs para InformÃ¡tica', 'No mundo contemporÃ¢neo presenciamos que o avanÃ§o da tecnologia proporcionou uma melhora na qualidade de vida das pessoas, na medida em que se faz necessÃ¡rio o entendimento de outra lÃ­ngua, no caso a inglesa, para melhor utilizaÃ§Ã£o das ferramentas disponÃ­veis.', 'https://www.baixelivros.com.br/media/2020/03/ingles-informatica.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_f91eaa847dde449188aecef8af0dd3c1.pdf', '2010-01-01', NULL),
(22, 'VÃ¡rios Autores', 'Ads', 'IFRN Editora', 'Curso: InformÃ¡tica AvanÃ§ada', 'A tecnologia Ã© bem mais que os artefatos e instrumentos materiais que manuseamos cotidianamente e que, atravÃ©s do desenvolvimento tecnolÃ³gico, o homem conseguiu se diferenciar ainda mais dos demais animais, adaptando-o Ã s suas necessidades.', 'https://www.baixelivros.com.br/media/2020/03/informatica-avancada.gif', 'https://domainpublic.files.wordpress.com/2024/01/livro_informatica_avancada_compressed.pdf', '2013-01-01', NULL),
(23, 'VÃ¡rios Autores', 'Idiomas', 'RÃ¡dio NKR', 'Curso de JaponÃªs', 'Nesse livro digital vocÃª pode aprender a gramÃ¡tica bÃ¡sica e expressÃµes Ãºteis do japonÃªs com os textos completos, as ilustraÃ§Ãµes das histÃ³rias da Anna. NÃ£o deixe de conferir e continue aprendendo japonÃªs de um jeito divertido!', 'https://www.baixelivros.com.br/media/2020/01/curso-de-japones.jpg', 'https://www.nhk.or.jp/lesson/update/pdf/leall_pt_t.pdf', '2015-01-01', NULL),
(24, 'VÃ¡rios Autores', 'Ads', 'Caelum', 'Curso: Java e OrientaÃ§Ãµes a Objetos', 'Muitos livros, ao passar dos capÃ­tulos, mencionam todos os detalhes da linguagem juntamente com seus princÃ­pios bÃ¡sicos. Isso acaba criando muita confusÃ£o, em especial porque o estudante nÃ£o consegue distinguir exatamente o que Ã© primordial aprender no inÃ­cio, daquilo que pode ser', 'https://www.baixelivros.com.br/media/2020/02/java-orientacao.jpg', 'https://www.caelum.com.br/apostila/apostila-java-orientacao-objetos.pdf', '2016-01-01', NULL),
(25, 'Gustavo Furtado', 'Ads', 'D.D.P', 'LÃ³gica de ProgramaÃ§Ã£o para Iniciantes', 'Criei este ebook com o intuito de te ajudar a criar uma base sÃ³lida de conhecimento que te permitirÃ¡ criar programas em qualquer linguagem de programaÃ§Ã£o que o mercado de trabalho requisitar. Ao longo deste ebook, vocÃª aprenderÃ¡ os conceitos bÃ¡sicos por trÃ¡s da programaÃ§Ã£o.', 'https://www.baixelivros.com.br/media/2019/07/programacao-para-iniciantes.jpg', 'https://dicasdeprogramacao.com.br/download/ebook-logica-de-programacao-para-iniciantes.pdf', '2019-01-01', NULL),
(26, 'ESESP', 'Processos', 'GEP', 'Curso: InglÃªs para Viagens', 'Objetivo do curso: adquirir vocabulÃ¡rio e desenvolver habilidades essenciais para se comunicar em situaÃ§Ãµes tÃ­picas de viagens (aeroporto, imigraÃ§Ã£o, tÃ¡xi, hotel,', 'https://www.baixelivros.com.br/media/2019/11/ingles-viagens.jpg', 'https://esesp.es.gov.br/Media/esesp/Apostilas/Ingles%20para%20Viagens.pdf', '2018-01-01', NULL),
(27, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'ABRAPP', 'Guia de Recrutamento â€“ SeleÃ§Ã£o de Pessoal', 'Este Guia tem por objetivo apresentar as prÃ¡ticas e diretrizes relacionadas ao processo de R & S para as entidades fechadas de previdÃªncia complementar. Nesse sentido, sugere-se que esse material seja customizado Ã  cultura e estratÃ©gia da organizaÃ§Ã£o.', 'https://www.baixelivros.com.br/media/2020/06/guia-de-recrutamento.jpg', 'https://www.funprespjud.com.br/wp-content/uploads/2018/05/Guia-de-Recrutamento-e-Selecao-de-Pessoal.pdf', '2015-01-01', NULL),
(28, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'PWC', 'Como Criar um Plano de NegÃ³cio', 'O Plano de NegÃ³cio ou Business Plan Ã© uma poderosa ferramenta gerencial para as empresas desde seu nascimento (start-up) atÃ© sua maturidade. Essa ferramenta Ã© vital para a continuidade da empresa, mesmo para aquelas que nÃ£o buscam qualquer tipo de recurso financeiro, capitalizaÃ§Ã£o ou posicionamento de mercado.', 'https://www.baixelivros.com.br/media/2020/05/plano-de-negocios.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_11ba93bed5ce4fccb532bfd096432a08.pdf', '2010-01-01', NULL),
(29, 'Bruno Andrade', 'Ads', 'GNU', '500 Comandos de Linux', 'Neste livro, vocÃª irÃ¡ encontrar mais de 500 comandos via terminal do Linux. Todos bem explicados da forma como funcionam e o que executam. Totalmente em portuguÃªs, com uma linguagem simples e objetiva que pode ser compreendida por todos os usuÃ¡rios (desde o nÃ­vel mais simples ao avanÃ§ado).', 'https://www.baixelivros.com.br/media/2020/04/guia-linux.jpg', 'https://www.linuxpro.com.br/dl/guia_500_comandos_Linux.pdf', '2016-01-01', NULL),
(30, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'BCB', 'EducaÃ§Ã£o Financeira BÃ¡sica', 'Todo cidadÃ£o pode desenvolver habilidades para melhorar sua qualidade de vida e a de seus familiares, a partir de atitudes comportamentais e de conhecimentos bÃ¡sicos sobre gestÃ£o de finanÃ§as pessoais aplicados no seu dia a dia.\r\n\r\n', 'https://www.baixelivros.com.br/media/2020/04/caderno-financeiro.jpg', 'https://www.bcb.gov.br/content/cidadaniafinanceira/documentos_cidadania/Cuidando_do_seu_dinheiro_Gestao_de_Financas_Pessoais/caderno_cidadania_financeira.pdf', '2013-01-01', NULL),
(35, 'VÃ¡rios Autores', 'Outros', 'EEEP', 'Curso: Desenho em Perspectiva', 'Ao nos depararmos com uma estrada de ferro, se nos posicionarmos de frente para ela, olhando-a em direÃ§Ã£o longitudinal, podemos observar curiosamente que, diante de nossos olhos, sua imagem vai se transformando ao longo da distÃ¢ncia.', 'https://www.baixelivros.com.br/media/2020/01/desenho-em-perspectiva.jpg', 'https://domainpublic.files.wordpress.com/2021/12/design_de_interiores_desenho_em_perspectiva-1.pdf', '2015-01-01', NULL),
(36, 'FÃ¡bio Mengue', 'Ads', 'UNICAMP', 'Curso: Java BÃ¡sico', 'Em 1991, um grupo de engenheiros da Sun Microsystems foi encarregado de criar uma nova linguagem que pudesse ser utilizada em pequenos equipamentos como controles de TV, telefones, fornos, geladeiras, etc.', 'https://www.baixelivros.com.br/media/2019/07/curso-java-basico.jpg', 'https://educafrotech.educafro.org.br/documents/java_basico.pdf', '2018-01-01', NULL),
(37, 'Machado de Assis', 'Literatura', 'MEC', 'MemÃ³rias PÃ³stumas de BrÃ¡s Cubas', 'A publicaÃ§Ã£o de â€œMemÃ³rias PÃ³stumas de BrÃ¡s Cubasâ€ nÃ£o sÃ³ inaugura o Realismo no Brasil, como inicia a etapa mais complexa da obra de Machado de Assis. Com ela, aprofunda-se a sua anÃ¡lise da realidade e refina-se a sua linguagem.', 'https://www.baixelivros.com.br/media/2019/02/bras-cubas.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_4f0243f83ea945ed98bfa7570d3b743c.pdf', '1880-03-01', NULL),
(38, 'Carlos Roberto Jamil Cury', 'Pedagogia', 'Cotez', 'Alceu Amoroso Lima', 'Ã‰ uma obra de 201\r\npÃ¡ginas e contÃ©m uma introduÃ§Ã£o do autor, cinco capÃ­tulos e uma bibliografia. Publicada pela\r\neditora Cortez/Autores Associados, impresso em 1984 em sua segunda ediÃ§Ã£o.\r\nNo prefÃ¡cio Alceu Amoroso Lima inicia dizendo que para â€œanalisar a tese do professor\r\nCarlos Roberto Jamil Cury, sÃ³ mesmo uma outra tese, semelhante Ã  sua, pela profundeza da\r\nerudiÃ§Ã£o e pela visÃ£o global do problemaâ€. Em seguida, com breves e concisas palavras diz\r\nque o trabalho do autor Ã© um estudo extremamente bem documentado e sintetizado no debate\r\nque se desencadeou na evoluÃ§Ã£o histÃ³rica moderna da EducaÃ§Ã£o Brasileira, a saber, o\r\nqÃ¼inqÃ¼Ãªnio inicial da revoluÃ§Ã£o de 1930. Diz ainda que o trabalho estÃ¡ centrado no debate que\r\ndividiu em dois grupos antagÃ´nicos â€œCatÃ³licos e Pioneirosâ€ por ele assim chamados de\r\nâ€œCatÃ³licos e Liberaisâ€. Afirma ainda, Alceu Amoroso Lima, que o nosso autor critica os dois\r\ngrupos e propÃµe uma terceira via, que Ã© a sua posiÃ§Ã£o marxologista, segundo a qual Ã© o fato\r\nessencial da humanidade estar dividida atÃ© hoje em oprimidos e opressores. E segundo Cury,\r\na finalidade da educaÃ§Ã£o Ã© superar e suprimir esta dicotomia. E termina o prefÃ¡cio dizendo:\r\nSeja como for o que hÃ¡ de superior nesta tese Ã© a honestidade e a amplitude da erudiÃ§Ã£o, a\r\nobjetividade na exposiÃ§Ã£o dos contendores, ...pelo conhecimento autÃªntico do passado,\r\nem seus aspectos positivos e negativos na concepÃ§Ã£o da tarefa pedagÃ³gica, como sendo\r\numa das bases capitais para o processo da civilizaÃ§Ã£o brasileira (p. IX).\r\nNa introduÃ§Ã£o, o nosso autor coloca, em linhas gerais, o objetivo da obra, o contexto\r\nda Ã©poca envolvendo a Igreja e a EducaÃ§Ã£o, bem como as proposiÃ§Ãµes e as hipÃ³teses do\r\ntrabalho e ainda uma noÃ§Ã£o de ideologia que vai permear a obra. ', 'https://m.media-amazon.com/images/I/91oxLEjr8XL._SY466_.jpg', 'https://edisciplinas.usp.br/pluginfile.php/7924527/mod_resource/content/1/Alceu%20Amoroso%20Lima.pdf', '2012-12-01', NULL),
(39, 'RenÃ© Zazzo', 'Pedagogia', 'Massangana', 'ALFRED BINET', 'â€œA antiga pedagogia Ã© como uma carruagem fora de moda:range, mas ainda pode ser Ãºtil. [A nova pedagogia] tem o aspectode uma mÃ¡quina de precisÃ£o; mas as peÃ§as parecem nÃ£o ter rela-Ã§Ã£o umas com as outras, e a mÃ¡quina tem um defeito: ela nÃ£ofunciona.â€Assim Alfred Binet se expressa no capÃ­tulo final de seu Ãºltimolivro, Ideias modernas sobre as crianÃ§as. Publicada em 1911, esta obra Ã©um balanÃ§o crÃ­tico do que â€œtrinta anos de pesquisas experimentais[...] nos ensinaram sobre as coisas da educaÃ§Ã£oâ€. Entretanto, oautor nÃ£o se limita a um resumo de suas pesquisas â€“ as suas e asdos outros â€“; ele se empenha em sugerir novas pesquisas, a esbo-Ã§ar, assim, â€œa obra de amanhÃ£â€. Mas nÃ£o haverÃ¡ amanhÃ£ para ele:Binet morre alguns meses depois da publicaÃ§Ã£o de seu livro. ObalanÃ§o toma, entÃ£o, ares de um testamento.â€œEu procurei meu caminhoâ€, disse ele, â€œentre a antiga peda-gogia e aquela que nos prometem os inovadores, gente do labora-tÃ³rio.â€ Foram lembradas suas palavras? Ou, pelo menos, engajamo-nos nesta via mediana considerada por Binet?', 'https://a-static.mlcdn.com.br/450x450/livro-alfred-binet-rene-zazzo/megabooks/9788570195333/7b5e27ed526a38fc3d5e930c80542105.jpeg', 'https://livros01.livrosgratis.com.br/me4661.pdf', '2010-10-21', NULL),
(40, 'Raquel Gandini', 'Pedagogia', 'Massangana', 'Almeida JÃºnior', 'O propÃ³sito de organizar uma coleÃ§Ã£o de livros sobre educa-dores e pensadores da educaÃ§Ã£o surgiu da necessidade de se colo-car Ã  disposiÃ§Ã£o dos professores e dirigentes da educaÃ§Ã£o de todoo paÃ­s obras de qualidade para mostrar o que pensaram e fizeramalguns dos principais expoentes da histÃ³ria educacional, nos pla-nos nacional e internacional. A disseminaÃ§Ã£o de conhecimentosnessa Ã¡rea, seguida de debates pÃºblicos, constitui passo importantepara o amadurecimento de ideias e de alternativas com vistas aoobjetivo republicano de melhorar a qualidade das escolas e daprÃ¡tica pedagÃ³gica em nosso paÃ­s.Para concretizar esse propÃ³sito, o MinistÃ©rio da EducaÃ§Ã£o insti-tuiu ComissÃ£o TÃ©cnica em 2006, composta por representantes doMEC, de instituiÃ§Ãµes educacionais, de universidades e da Unescoque, apÃ³s longas reuniÃµes, chegou a uma lista de trinta brasileiros etrinta estrangeiros, cuja escolha teve por critÃ©rios o reconhecimentohistÃ³rico e o alcance de suas reflexÃµes e contribuiÃ§Ãµes para o avanÃ§oda educaÃ§Ã£o. No plano internacional, optou-se por aproveitar a co-leÃ§Ã£o  Penseurs de lÂ´Ã©ducation, organizada pelo International Bureau ofEducation (IBE) da Unesco em Genebra, que reÃºne alguns dos mai-ores pensadores da educaÃ§Ã£o de todos os tempos e culturas.Para garantir o Ãªxito e a qualidade deste ambicioso projetoeditorial, o MEC recorreu aos pesquisadores do Instituto PauloFreire e de diversas universidades, em condiÃ§Ãµes de cumprir osobjetivos previstos pelo projeto', 'https://img.skoob.com.br/GPEV4P2yYPj71mQAFASOssVe3zg=/600x0/center/top/filters:format(jpeg)/https://skoob.s3.amazonaws.com/livros/233807/ALMEIDA_JUNIOR_1337038424B.jpg', 'https://www.livrosgratis.com.br/ler-livro-online-81378/almeida-junior', '2010-01-01', NULL),
(41, 'GregÃ³rio Weinberg', 'Pedagogia', 'Massangana', 'AndrÃ©s Bello', 'AndrÃ©s Bello Ã© figura exemplar da histÃ³ria da cultura da AmÃ©rica Latina: ele foi um dos educadores mais importantes do sÃ©culo\r\nXIX e Ã© considerado o maior humanista desse perÃ­odo. Sua personalidade equilibrada, sua vida austera de erudito fazem dele um\r\nverdadeiro Mestre â€“ termo que se reveste, em espanhol, de inÃºmeras acepÃ§Ãµes, desde o sentido de â€œpessoa que ensina em uma\r\nescola primÃ¡riaâ€ atÃ© ao elogioso â€œpessoa de grande mÃ©ritoâ€. Escrita com letra maiÃºscula, a palavra constitui, alÃ©m disso, uma marca de deferÃªncia a uma personalidade eminente, extraordinÃ¡ria.\r\nNo caso de AndrÃ©s Bello, todas essas acepÃ§Ãµes se combinam. Sua\r\nvasta e perene obra revela o interesse que ele demonstrou pela\r\nescola primÃ¡ria e, mais ainda, pela universidade. A isso, soma-se\r\nsua atuaÃ§Ã£o como gramÃ¡tico, jurista, filÃ³sofo e polÃ­tico.\r\nNasceu na Venezuela, mas os rumos da histÃ³ria da AmÃ©rica\r\nLatina no princÃ­pio do sÃ©culo XIX conduziram-no a Londres, onde ele permaneceria por duas dÃ©cadas antes de estabelecer-se no Chile. A abrangÃªncia de sua obra e a influÃªncia que ela nunca deixou\r\nde exercer conferiram a ele grande prestÃ­gio em todo o continente\r\nlatino-americano e explicam o fato excepcional de que, atÃ© nossos\r\ndias, todos os falantes de lÃ­ngua espanhola o reivindiquem para si.\r\nSeu brilho Ã© tamanho que atÃ© acordos internacionais de carÃ¡ter\r\neducativo e cultural levam seu nome.', 'https://m.media-amazon.com/images/I/21jmaVRV+XL.jpg', 'https://www.santoandre.sp.gov.br/biblioteca/pesquisa/ebooks/358891.PDF', '2010-01-01', NULL),
(42, 'Clarice Nunes', 'Pedagogia', 'UNESCO', 'AnÃ­sio Teixeira', 'O artigo evidencia a contribuiÃ§Ã£o de AnÃ­sio Teixeira com relaÃ§Ã£o Ã  formaÃ§Ã£o do educador. ApÃ³s uma apresentaÃ§Ã£o sucinta dos seus dados biogrÃ¡ficos, discute-se a possibilidade de resgatar o desejo pela educaÃ§Ã£o, marca da atuaÃ§Ã£o desse intelectual, e compreender como se atualiza a importÃ¢ncia da educaÃ§Ã£o e do educador no mundo globalizado. Destaca-se o papel do professor e dos seus saberes, o paradoxo da importÃ¢ncia estratÃ©gica da sua atuaÃ§Ã£o e, ao mesmo tempo, sua desvalorizaÃ§Ã£o social na atualidade. Nessa anÃ¡lise, resgatam-se as concepÃ§Ãµes e iniciativas de AnÃ­sio Teixeira, no sentido de tornar a educaÃ§Ã£o uma Ã¡rea de investigaÃ§Ã£o acadÃªmica e articular o trabalho de educadores e cientistas sociais na direÃ§Ã£o de um ensino de qualidade na escola pÃºblica. Conclui-se com uma reflexÃ£o sobre o nosso papel e nossa funÃ§Ã£o como profissionais da educaÃ§Ã£o enfrentando os dilemas do presente.', 'https://d1pkzhm5uq4mnt.cloudfront.net/imagens/capas/c83bc1630039d8ba969294d1363619a19f2786e7.jpg', 'https://www.livrosgratis.com.br/ler-livro-online-84596/anisio-teixeira', '2001-04-01', NULL),
(43, 'Monasta, Attilio', 'Pedagogia', 'Massangana', 'Antonio Gramsci', 'O propÃ³sito de organizar uma coleÃ§Ã£o de livros sobre educadores e pensadores da educaÃ§Ã£o surgiu da necessidade de se colocar Ã  disposiÃ§Ã£o dos professores e dirigentes da educaÃ§Ã£o de todo\r\no paÃ­s obras de qualidade para mostrar o que pensaram e fizeram\r\nalguns dos principais expoentes da histÃ³ria educacional, nos planos nacional e internacional. A disseminaÃ§Ã£o de conhecimentos\r\nnessa Ã¡rea, seguida de debates pÃºblicos, constitui passo importante\r\npara o amadurecimento de ideias e de alternativas com vistas ao\r\nobjetivo republicano de melhorar a qualidade das escolas e da\r\nprÃ¡tica pedagÃ³gica em nosso paÃ­s.\r\nPara concretizar esse propÃ³sito, o MinistÃ©rio da EducaÃ§Ã£o instituiu ComissÃ£o TÃ©cnica em 2006, composta por representantes do\r\nMEC, de instituiÃ§Ãµes educacionais, de universidades e da Unesco\r\nque, apÃ³s longas reuniÃµes, chegou a uma lista de trinta brasileiros e\r\ntrinta estrangeiros, cuja escolha teve por critÃ©rios o reconhecimento\r\nhistÃ³rico e o alcance de suas reflexÃµes e contribuiÃ§Ãµes para o avanÃ§o\r\nda educaÃ§Ã£o. No plano internacional, optou-se por aproveitar a coleÃ§Ã£o Penseurs de lÂ´Ã©ducation, organizada pelo International Bureau of\r\nEducation (IBE) da Unesco em Genebra, que reÃºne alguns dos maiores pensadores da educaÃ§Ã£o de todos os tempos e culturas.\r\nPara garantir o Ãªxito e a qualidade deste ambicioso projeto\r\neditorial, o MEC recorreu aos pesquisadores do Instituto Paulo\r\nFreire e de diversas universidades, em condiÃ§Ãµes de cumprir os\r\nobjetivos previstos pelo projeto', 'https://m.media-amazon.com/images/I/81njIzWpAdL._SL1500_.jpg', 'https://www.livrosgratis.com.br/ler-livro-online-84796/antonio-gramsci', '2010-02-01', NULL),
(44, 'G. N. Filonov', 'Pedagogia', 'Massangana', 'Anton Makarenko', 'A evoluÃ§Ã£o da teoria pedagÃ³gica e do sistema de ensino foi, naURSS, estreitamente ligada Ã s inovaÃ§Ãµes cientÃ­ficas e ao trabalho prÃ¡-tico de toda uma plÃªiade de eminentes educadores. Entre os gran-des educadores soviÃ©ticos que lutaram ativamente para que as ideiase os princÃ­pios democrÃ¡ticos fossem reconhecidos na teoria e naprÃ¡tica pedagÃ³gicas, Anton Semionovitch Makarenko (1888-1939)desempenhou um papel de primeiro plano. Seu nome figura, comrazÃ£o, no nÃºmero de clÃ¡ssicos da pedagogia mundial e seus livros,publicados em milhÃµes de exemplares em todos os continentes,desfrutam de imensa popularidade. Em numerosos paÃ­ses, reali-zam-se pesquisas sobre suas atividades e tenta-se aplicar suas ideias Ã prÃ¡xis pedagÃ³gica. Todavia, nÃ£o Ã© raro que, nos estudos especializadoscomo nas obras destinadas ao grande pÃºblico, o caso Makarenkoseja ainda apresentado de modo parcial e atÃ© mesmo errÃ´neo.Certos especialistas estrangeiros consideram Makarenko um â€œau-todidata genialâ€ e apresentam seu sistema pedagÃ³gico sem nunca sereferirem Ã  tradiÃ§Ã£o nem Ã  atualidade pedagÃ³gicas progressistas. Ã‰ verdade que, nas obras publicadas, muito cÃ©lebres de Makarenko,encontram-se relativamente poucas indicaÃ§Ãµes sobre as relaÃ§Ãµes coma tradiÃ§Ã£o da pedagogia mundial e com os grandes especialistas daeducaÃ§Ã£o, soviÃ©ticos e estrangeiros, que eram seus contemporÃ¢neos.Mas, pesquisas documentais recentemente realizadas por especialistassoviÃ©ticos3 mostram que, malgrado uma origem muito modesta euma juventude difÃ­cil â€” seu pai era pintor de parede e ele comeÃ§ou trabalhar aos 17 anos, como professor primÃ¡rio em uma escola queacolhia filhos dos empregados de estrada de ferro â€”, Makarenkoconhecia muito bem a histÃ³ria da pedagogia. Muitos dos grandesprincÃ­pios que estabeleceu em teoria e verificou na prÃ¡tica inspiram-se nas ideias de Pestalozzi, Owen, Uchinski, Dobroliubov e em ou-tros grandes nomes da histÃ³ria da pedagogia democrÃ¡tica mundial.', 'https://s3.amazonaws.com/acervo.i10bibliotecas/rede-sagrado/material-livro-similar/v6rh/c61563e90892d15fb209257c2c293e5d_b.jpg', 'https://www.livrosgratis.com.br/ler-livro-online-84800/anton-makarenko', '2010-01-01', NULL),
(45, 'VÃ¡rios Autores', 'Ads', 'Cecierj', 'Curso: Java BÃ¡sico e OrientaÃ§Ã£o a Objeto', 'Para mostrarmos a importÃ¢ncia do aprendizado da linguagem de programaÃ§Ã£o Java, precisamos antes fazer uma retrospectiva sobre programaÃ§Ã£o e suas linguagens atravÃ©s dos tempos, ate chegarmos em Java.', 'https://www.baixelivros.com.br/media/2022/05/java-basico.jpg', 'https://canal.cecierj.edu.br/012016/d7d8367338445d5a49b4d5a49f6ad2b9.pdf', '2021-01-01', NULL),
(46, 'VÃ¡rios Autores', 'Pedagogia', 'EducaÃ§Ã£o InovaÃ§Ã£o', 'MatemÃ¡tica: 1Âº Ano â€“ BNCC Atividades', 'Adotamos como Ã¢ncora do trabalho com as sequÃªncias didÃ¡ticas, a perspectiva da interdisciplinaridade, pois nela hÃ¡ o intercÃ¢mbio e interaÃ§Ã£o de diversos conhecimentos de forma coordenada, nÃ£o afetando os interesses prÃ³prios de cada componente curricular.', 'https://www.baixelivros.com.br/media/2022/01/matematica-primeiro-bncc.jpg', 'https://domainpublic.files.wordpress.com/2022/01/sd-matemacc81tica-1o-ano.pdf', '2021-01-01', NULL),
(47, 'VÃ¡rios Autores', 'Pedagogia', 'MinistÃ©rio da EducaÃ§Ã£o', 'Curso: Professores de MatemÃ¡tica', 'Estamos muito satisfeitos em tÃª-lo conosco nesta â€œaventuraâ€. Isto porque acreditamos que ao participar deste curso vocÃª volta a ser estudante. E ser estudante Ã© uma aventura. Ser estudante Ã© um desafio novo que surge na sua vida pessoal, familiar e profissional.', 'https://www.baixelivros.com.br/media/2020/06/curso-professores-matematica.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_3dab0dbb000f413cb919561dbe586d87.pdf', '2008-01-01', NULL),
(48, 'VÃ¡rios Autores', 'Pedagogia', 'Seed-PR', 'ColetÃ¢nea de Atividades â€“ MatemÃ¡tica', 'As Atividades sugeridas neste Caderno foram elaboradas para favorecer a sua inteligÃªncia, numa demonstraÃ§Ã£o clara de que Ã© possÃ­vel organizar coletivamente conhecimentos fundamentais que garantam as oportunidades de desenvolvimento escolar.', 'https://www.baixelivros.com.br/media/2021/02/coletanea-de-atividades-matematica.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_1dc31fc47d5f43abaec351692d89054e.pdf', '2005-01-01', NULL),
(49, 'VÃ¡rios Autores', 'Pedagogia', 'Secretaria da EducaÃ§Ã£o', 'MatemÃ¡tica Infantil: 500 Atividades', 'Problema Ã© toda a situaÃ§Ã£o de aprendizagem que coloca a crianÃ§a frente a um desafio e provoca uma tomada de decisÃ£o. Para ser um desafio, o ideal Ã© que o aluno nÃ£o tenha de antemÃ£o, todas as ferramentas necessÃ¡rias Ã  resoluÃ§Ã£o do problema.', 'https://www.baixelivros.com.br/media/2021/03/atividades-matematica-aprender.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_997549563da64be89ed4dfbc4c546bb2.pdf', '2020-01-01', NULL),
(50, 'MarÃ­lia Gaspar', 'Pedagogia', 'Nova Escola', '4Âº Ano Fundamental (Port/Mat)', 'No decorrer destas pÃ¡ginas, vocÃª serÃ¡ desafiado a explorar sua criatividade e a aprimorar seu conhecimento por meio de diferentes propostas, sempre buscando contemplar a diversidade e as riquezas.\r\n\r\n<a href=\"https://domainpublic.files.wordpress.com/2022/02/c.a-4o-ano-aluno.pdf\">link do aluno</a>', 'https://www.baixelivros.com.br/media/2022/02/caderno-do-aluno.jpg', 'https://domainpublic.files.wordpress.com/2022/02/c.a-4o-ano-prof.pdf', '2021-01-01', NULL),
(51, 'Eduardo BrÃ¡ulio', 'Ads', 'CEFET-RN Editora', 'Arquitetura de Computadores', 'Um material especÃ­fico para cursos de graduaÃ§Ã£o tecnolÃ³gica com Ãªnfase em software, trarÃ¡ os temas mais relevantes da Ã¡rea de Arquitetura de Computadores Ã  luz sob este prisma, dando oportunidade para uma abordagem mais precisa e aprofundada.', 'https://www.baixelivros.com.br/media/2020/03/arquitetura-de-computadores.jpg', 'https://memoria.ifrn.edu.br/bitstream/handle/1044/982/Arquitetura%20de%20Computadores%20-%20Ebook.pdf?sequence=1&isAllowed=y', '2005-01-01', NULL),
(52, 'Ernesto Puccini', 'AdministraÃ§Ã£o', 'UFSC', 'MatemÃ¡tica Financeira e AnÃ¡lise de Investimentos', 'Este livro pretende ajudÃ¡-lo a desvendar essas tÃ©cnicas para que vocÃª possa gerir os seus interesses financeiros e os da sua organizaÃ§Ã£o com racionalidade e eficiÃªncia. No decorrer dos estudos lhe sugeriremos atividades com a finalidade de facilitar seu aprendizado.', 'https://www.baixelivros.com.br/media/2020/02/matematica-financeira-investimentos.jpg', 'https://canal.cecierj.edu.br/012016/d477f2f77a93e854d511fb69c11eb948.pdf', '2016-01-01', NULL),
(53, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'Finance One', 'Guia do Investidor Iniciante', 'Se vocÃª nÃ£o Ã© da Ã¡rea financeira e, principalmente, se Ã© â€˜de Humanasâ€™ ou ainda, nÃ£o consegue compreender como o mercado financeiro funciona, deve chegar a tremer de pavor quando ouve a palavra investimento. Parece coisa sÃ©ria (e Ã© mesmo). Mas nÃ£o Ã© todo esse bicho de sete cabeÃ§as que aparenta.', 'https://www.baixelivros.com.br/media/2020/02/investidor-iniciante.jpg', 'https://financeone.com.br/wp-content/uploads/2017/12/E-book-Investidor-Iniciante.pdf', '2017-01-01', NULL),
(54, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'EdiÃ§Ãµes CÃ¢mara', 'Capital Empreendedor', 'A publicaÃ§Ã£o Ã© o quarto volume da sÃ©rie Estudos EstratÃ©gicos e analisa os investimento em empresas de capital fechado que apresentam alto potencial de crescimento, mas cujos projetos dependam da injeÃ§Ã£o de novos recursos.', 'https://www.baixelivros.com.br/media/2020/03/capital-empreendedor.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_a145346cb56e4d6581a12ba04263c762.pdf', '2014-01-01', NULL),
(55, 'Deise Peralta', 'Ads', 'Fi', 'RobÃ³tica e Processos Formativos', 'A robÃ³tica diz respeito a sistemas compostos por partes mecÃ¢nicas controladas por circuitos elÃ©tricos. Na realidade, a robÃ³tica Ã© atualmente uma das principais e mais relevantes vertentes.', 'https://www.baixelivros.com.br/media/2020/03/robotica-e-processos.jpg', 'https://3c290742-53df-4d6f-b12f-6b135a606bc7.usrfiles.com/ugd/48d206_1b5275571b234d739eaa722ca244015c.pdf', '2012-01-01', NULL),
(56, 'Ivo Mathias', 'Ads', 'MEC', 'AlgorÃ­timos e ProgramaÃ§Ã£o II', 'Esse disciplina possui uma abordagem teÃ³rica e prÃ¡tica. Sendo assim, o acompanhamento integral deste livro digital Ã© de fundamental importÃ¢ncia para assimilar todas as definiÃ§Ãµes, acompanhar os exemplos e fazer os exercÃ­cios propostos.', 'https://www.baixelivros.com.br/media/2020/02/algoritimos-e-programacao.jpg', 'https://domainpublic.files.wordpress.com/2022/03/algoritmos-e-programacao-ii.pdf', '2017-01-01', NULL),
(57, 'Marco Agner', 'Ads', 'ITSRIO', 'Bitcoin para Programadores', 'Este material tem o objetivo de introduzir programadores com interesse nascente nesta tecnologia aos conceitos bÃ¡sicos necessÃ¡rios para o entendimento e desenvolvimento de aplicaÃ§Ãµes Bitcoin. O foco Ã© o mais prÃ¡tico sem perder de vista a teoria necessÃ¡ria.', 'https://www.baixelivros.com.br/media/2020/02/bitcoin-programadores.jpg', 'https://itsrio.org/wp-content/uploads/2018/06/bitcoin-para-programadores.pdf', '2018-01-01', NULL),
(58, 'Jefferson Ferreira', 'AdministraÃ§Ã£o', 'IFRN', 'Manual de Vendas', 'O livro â€œManual De Vendas Para Novos Vendedoresâ€ objetiva oferecer a autocapacitaÃ§Ã£o a um pÃºblico que Ã©, em minha opiniÃ£o, a mola mestra impulsionadora para o alcance dos objetivos comerciais das corporaÃ§Ãµes.', 'https://www.baixelivros.com.br/media/2020/02/manual-de-vendas.jpg', 'https://5ca0e999-de9a-47e0-9b77-7e3eeab0592c.usrfiles.com/ugd/5ca0e9_e66b29cc5e9445b39d3b81bdeb9685ff.pdf', '2011-01-01', NULL),
(59, 'VÃ¡rios Autores', 'Processos', 'Team Culture', '10 Pilares Engajamento', 'VocÃª jÃ¡ se questionou se seu sistema de GestÃ£o Ã© o mais eficiente para obter os resultados que a empresa necessita para alcanÃ§ar o sucesso? Se lhe perguntarmos qual o grau de engajamento de seus colaboradores vocÃª terÃ¡ esta resposta?', 'https://www.baixelivros.com.br/media/2019/09/10-Pilares-Engajamento.jpg', 'https://teamculture.s3.amazonaws.com/e-books/Ebook10PilaresEngajamento.pdf', '2019-01-01', NULL),
(60, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'Clear', 'AnÃ¡lise TÃ©cnica â€“ Operando AtravÃ©s de GrÃ¡ficos', 'A anÃ¡lise tÃ©cnica, tambÃ©m conhecida como anÃ¡lise grÃ¡fica, Ã© a tÃ©cnica em que sÃ£o utilizados grÃ¡ficos para determinar o momento de entrada e saÃ­da de um ativo, ou seja, Ã© uma ferramenta que estÃ¡ mais voltada para o â€œtraderâ€, isto Ã©, para aquele investidor preparado para entrar e sairâ€¦', 'https://www.baixelivros.com.br/media/2020/02/analise-tecnica.jpg', 'https://www.clear.com.br/site/Content/pdf/download-ebooks/eBook-AnaliseTecnica.pdf', '2010-01-01', NULL),
(61, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'Clear', 'Renda Fixa â€“ Guia BÃ¡sico', 'Investir em Renda Fixa Ã© o mesmo que emprestar dinheiro para um banco, empresa ou para o governo, e em contrapartida vocÃª (investidor) recebe uma remuneraÃ§Ã£o. Essa Ã© uma forma de captar recursos e financiar projetos ou negÃ³cios para quem emite esses tÃ­tulos.', 'https://www.baixelivros.com.br/media/2020/02/renda-fixa.jpg', 'https://www.clear.com.br/site/Content/pdf/ebook_clear_renda_fixa.pdf', '2010-01-01', NULL),
(62, 'VÃ¡rios Autores', 'AdministraÃ§Ã£o', 'Clear', 'Renda Fixa â€“ Guia BÃ¡sico', 'Investir em Renda Fixa Ã© o mesmo que emprestar dinheiro para um banco, empresa ou para o governo, e em contrapartida vocÃª (investidor) recebe uma remuneraÃ§Ã£o. Essa Ã© uma forma de captar recursos e financiar projetos ou negÃ³cios para quem emite esses tÃ­tulos.', 'https://www.baixelivros.com.br/media/2020/02/renda-fixa.jpg', 'https://www.clear.com.br/site/Content/pdf/ebook_clear_renda_fixa.pdf', '2010-01-01', NULL);

-- --------------------------------------------------------
--
-- Estrutura para tabela `usuarios_biblioteca`
--

CREATE TABLE `usuarios_biblioteca` (
  `id` int(10) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `tipo` varchar(12) NOT NULL,
  `senha` varchar(100) NOT NULL,
  `nivel` varchar(15) NOT NULL DEFAULT 'comum',
  `foto_url` varchar(1000) DEFAULT NULL,
  `cod_operation` int(6) DEFAULT NULL,
  `data_operation_exp` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Despejando dados para a tabela `usuarios_biblioteca`
--

INSERT INTO `usuarios_biblioteca` (`id`, `nome`, `email`, `tipo`, `senha`, `nivel`, `foto_url`, `cod_operation`, `data_operation_exp`) VALUES
(17, 'lyncon', 'lyncon@gmail.com', 'Professor', '$2y$08$ynHzWGVzBBhssasw32239DhW2vIrkO.wNyTyphbWzHy9AIXtmXPso1t1msFqra', 'comum', NULL, NULL, NULL),
(12, 'kayo  Martins ', 'kayo.drive@gmail.com', 'Aluno', '$2y$10$25b4EhJeqZ6B7tg46nO31uyP23523432yWqdDNh6eLcudeMsgOlhOvzqTDfFe', 'administrador', 'https://cdn.vox-cdn.com/thumbor/PqAwdNpc7p-5GUCSMxQPehSU-ck=/0x0:1920x1200/1200x800/filters:focal(810x375:1116x681)/cdn.vox-cdn.com/uploads/chorus_image/image/72524797/pikachu_artwork.0.jpg', 643874, '2024-03-20 09:18:35'),
(16, 'MARIA SOARES', 'contato.marias@gmail.com', 'Outro', '$2y$009-888$ZOwb9NmeXFpju4FkPVW.9.ovNdJi4NgCm4NID9odlu38W9B9aUwR2', 'administrador', NULL, NULL, NULL);

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `comentarios_livros`
--
ALTER TABLE `comentarios_livros`
  ADD PRIMARY KEY (`cod_coment`);

--
-- Índices de tabela `historico_biblioteca`
--
ALTER TABLE `historico_biblioteca`
  ADD PRIMARY KEY (`id_hist`);

--
-- Índices de tabela `livros`
--
ALTER TABLE `livros`
  ADD PRIMARY KEY (`cod_livro`);
--
-- Índices de tabela `usuarios_biblioteca`
--
ALTER TABLE `usuarios_biblioteca`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `comentarios_livros`
--
ALTER TABLE `comentarios_livros`
  MODIFY `cod_coment` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de tabela `historico_biblioteca`
--
ALTER TABLE `historico_biblioteca`
  MODIFY `id_hist` bigint(60) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=291;
--
-- AUTO_INCREMENT de tabela `livros`
--
ALTER TABLE `livros`
  MODIFY `cod_livro` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;
--
-- AUTO_INCREMENT de tabela `usuarios_biblioteca`
--
ALTER TABLE `usuarios_biblioteca`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
