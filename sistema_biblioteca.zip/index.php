<?php
session_start();

if(!empty($_SESSION)){
if(!($_SESSION['user'] == null) && !($_SESSION['senha'] ==null)){
  header('location:./dashboard.php');
}
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="http://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
var url_string = window.location.href;
var url = new URL(url_string);
var data = url.searchParams.get("erro"); 
if(data == '0AS0'){
    alert("Usuário Inválido!");
}
if(data == 'S0I1'){
    alert("Senha Inválida!");
}
if(data == 'C0J1'){
    alert("Email Já Cadastrado!, realize o Login!");
}
if(data =='SA11'){
    alert("Senha Alterada, Realize o Login!");
}
</script>
</head>
<body>

<div class="container login-container">
            <div class="row">
                <div class="col-md-6 login-form-1">
                    <img src="https://img.freepik.com/fotos-premium/uma-imagem-com-um-fundo-desfocado-mostra-uma-estante-de-biblioteca-com-muitos-livros-nela_410516-43749.jpg" width="100%">
                </div>
                <div class="col-md-6 login-form-2">
                    <h3>Login Biblioteca Online</h3>
                    <form method="post" action="./php/login.php" autocomplete="on">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Seu Email *" name="email" value="" autofocus/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-control" placeholder="Sua Senha *" name="senha" value="" />
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btnSubmit" name="login" value="Login" />
                        </div>
                         <div class="form-check form-switch" style="margin-top: 1.2rem;color: white; font-weight: bold; display:none;">
                            <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                            <label class="form-check-label" for="flexSwitchCheckDefault">Manter Logado</label>
                        </div>
                    </form>
                    <div class="form-group" style="margin-top: 1.2rem; text-align:center;">
                            <a href="./php/esqueceu.php" class="ForgetPwd" value="Login">Esqueceu a senha?</a>
                        </div>
                    <div class="form-group" style="margin-top: 1.2rem;color: white; font-weight: bold; text-align: center;">
                        Não tem Cadastro? <a href="cadastro.php" class="ForgetPwd"> cadastre-se aqui</a>
                    </div>
                </div>
            </div>
        </div>
</body>
</html>