$(document).ready(function () {

    $('#nome_filter').change(function () {
        $('#form_filter').submit(function () {
            var dados = $(this).serialize();

            $.ajax({
                url: '../php/pesquisar_filtro.php',
                method: 'POST',
                dataType: 'html',
                data: dados,
                success: function (data) {
                    $('#resultado').empty().html(data);
                }
            });
            return false;
        });
        $('#form_filter').trigger('submit'); 

    });
});