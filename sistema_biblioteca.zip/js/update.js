function atualizarnome(){
//alert('entrou nome');
var nome = document.getElementById("nome").value;
}
function atualizarfoto(){
  //  alert('entrou foto');
    var nome = document.getElementById("nome").value;
    }
    function atualizaremail(){
    //    alert('entrou email');
        var nome = document.getElementById("nome").value;
        }
        function atualizartipo(){
      //      alert('entrou tipo');
            var nome = document.getElementById("nome").value;
            }