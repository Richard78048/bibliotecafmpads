<?php
include './php/verifica_login_ativo.php';
include './php/sql.php';
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set('America/Sao_Paulo');
//salvar historico
include './php/inserir_historico.php';
//salvar historico
$livro = $_GET['cod_livro'];
 $selectdb = $conectdb -> prepare("SELECT * FROM livros WHERE cod_livro ='$livro'");
	$selectdb -> execute();
	$retorno_linhas = $selectdb -> fetchAll(PDO::FETCH_ASSOC);
foreach ($retorno_linhas as $row) {
    $titulo=$row['titulo'];
    $data_publicacao=$row['data_publicacao'];
    $descricao=$row['descricao'];
    $url_capa=$row['url_capa'];
    $autor=$row['autor'];
    $editora=$row['editora'];
    $genero=$row['genero'];
    $url_arquivo=$row['url_arquivo'];
}
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/css.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://mozilla.github.io/pdf.js/build/pdf.js"></script>
    <script src="https://mozilla.github.io/pdf.js/build/pdf.worker.js"></script>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <title>Biblioteca FMP ADS</title>
    <style>
    .estrelas{padding-bottom:0.5em;}
    .estrelas input[type=radio] {
    display: none;
    }
    .estrelas label i.fa{
    font-size: 1.5em
    }
    .estrelas label i.fa:before {
    content:'\f005';
    color: #FC0;
    }
    .estrelas input[type=radio]:checked ~ label i.fa:before {
    color: #CCC;
    }
    #pdf_reader{
        display:none;
        width:100%;
        height:100vh;
    }
    </style>
    <script>
      var url_string = window.location.href;
      var url = new URL(url_string);
      var data = url.searchParams.get("erro"); 
      if(data == 'CMT1'){
          alert("Vc já Comentou, Não é permitido Comentar mais!");
      }
      if(data == 'CMD1'){
          alert("Comentário Deletado!");
      }
</script>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="dashboard.php">Biblioteca FMP ADS</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown" style="justify-content: flex-end;">
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <?php echo $_SESSION['nome']; ?>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
                  </svg>
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="dados_pessoais.php">Dados Pessoais</a></li>
                  <?php
                  if($_SESSION['nivel'] === 'administrador') {
                  echo '<li><a class="dropdown-item" href="publicar_livro.php">Publicar</a></li>'; 
                  }
                  ?>
                  <li><a class="dropdown-item" href="historico.php">Histórico</a></li>
                  <li><a class="dropdown-item" href="./php/sair.php?sair=sim">Sair</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card" style="margin-top: 1rem;">
                    <div class="card-header" style="display: flex; justify-content: space-between;">
                      <h5 class="card-title"> <?php echo $titulo; ?> </h5>
                      <p class="publicado">Publicado em: <?php echo date('d/m/Y', strtotime($data_publicacao)); ?></p>
                    </div>
                    <div class="card-body">
                    <img class="card-img-left" style="float: left; padding-right:5px;" width="120rem" src="<?php echo $url_capa; ?>" alt="Imagem de capa do card">
                    <p class="card-text">
                       <?php echo $descricao; ?>
                    </p>
                    <p class="card-text"> 
                    Autor: <?php echo $autor; ?><br>
                    Editora: <?php echo $editora; ?><br>
                    Gênero: <?php echo $genero; ?>
                    </p>
                    <a href="#pdf_reader" class="btn btn-primary" style="float: right;margin-left: 1.2rem;" onclick="ler()">Ler Online</a>
                    <a href="<?php echo $url_arquivo; ?>" download class="btn btn-primary" style="float: right;" target="_blank">Download</a>
                    </div>
                </div>
            </div>
            
            <div class="col-md-4">
                <div class="card" style="margin-top: 1rem;">
                    <div class="card-header">
                        <h5 class="card-title"> Comentários:</h5>
                    </div>
                    <div class="card-body" style="border-bottom:1px solid silver;">
                        <p>
                            <img src="./img/user.png" class="card-img-top" style="width: 3rem;"> <i> <?php echo $_SESSION['nome']; ?></i>
                        </p>
                      <p class="card-text">
                      <form id='form-comentar' method="POST" action="./php/comentar.php">
                        <div class="estrelas">
                        <input type="radio" id="cm_star-empty" name="stars" value="" checked required/>
                        <label for="cm_star-1"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-1" name="stars" value="1"/>
                        <label for="cm_star-2"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-2" name="stars" value="2"/>
                        <label for="cm_star-3"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-3" name="stars" value="3"/>
                        <label for="cm_star-4"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-4" name="stars" value="4"/>
                        <label for="cm_star-5"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-5" name="stars" value="5"/>
                        </div>
                      <textarea name="comentario" style="min-width:100%;" rows="3" placeholder="Seu Comentário" required></textarea>
                      <button type="submit" class="btn btn-primary" name="cod_livro" value="<?php echo $livro;?>" style="float: right; margin-top:0.5rem;" >
                      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" fill="currentColor" class="bi bi-chat-dots" viewBox="0 0 16 16">
                        <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
                        <path d="m2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9 9 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.4 10.4 0 0 1-.524 2.318l-.003.011a11 11 0 0 1-.244.637c-.079.186.074.394.273.362a22 22 0 0 0 .693-.125m.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6-3.004 6-7 6a8 8 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a11 11 0 0 0 .398-2"/>
                    </svg>
                      Comentar</button>
                      </p>
                    </div>

                    <?php include './php/exibe_comentarios_livro.php'; ?>
                  </div>
            </div>
        </div>
      </div>
      </form>
      <object id="pdf_reader" class="pdf_reader" data="<?php echo $url_arquivo; ?>" type="application/pdf">
        <p><iframe src="https://docs.google.com/viewer?url=<?php echo $url_arquivo; ?>&embedded=true" style="width:100%; height:100%;" frameborder="0"></iframe></p>

    </object>
    <script>
        function ler(){
            var pdfReader = document.getElementById('pdf_reader');
            pdfReader.style.display = 'block';
        }
    </script>
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="https://assets.locaweb.com.br/locastyle/3.10.1/javascripts/locastyle.js" type="text/javascript"></script>
</body>
</html>