<?php
include './php/verifica_login_ativo.php';
include './php/sql.php';
$id = $_SESSION['id'];
 $tarefa03 = $conectdb->query("SELECT * FROM usuarios_biblioteca WHERE id='$id'");
    $user_result3 = $tarefa03->fetch();
   if ($user_result3> 0) {
    $nome = $user_result3['nome'];
    $email = $user_result3['email'];
    $tipo = $user_result3['tipo'];
    $nivel = $user_result3['nivel'];
    if(isset($user_result3['foto_url']) && !empty($user_result3['foto_url'])){
        $foto = $user_result3['foto_url'];
        $class = "redondo";
    }else{ $foto = "./img/user.png"; $class='';}
    
}
?>
<html lang="br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/css.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/update.js" type="text/javascript"></script>
    <title>Biblioteca FMP ADS</title>
    <style>
    .redondo{
    border-radius: 50% 50% 50% 50% !important;
    height:10em;
}
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="dashboard.php">Biblioteca FMP ADS</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown" style="justify-content: flex-end;">
            <ul class="navbar-nav">
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                   <?php echo $_SESSION['nome']; ?>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
                  </svg>
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="#">Dados Pessoais</a></li>
                  <?php
                  if($_SESSION['nivel'] === 'administrador') {
                  echo '<li><a class="dropdown-item" href="publicar_livro.php">Publicar</a></li>'; 
                  }
                  ?>
                  <li><a class="dropdown-item" href="historico.php">Histórico</a></li>
                  <li><a class="dropdown-item" href="./php/sair.php?sair=sim">Sair</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>
<!-- modals -->
<!-- Button trigger modal -->
<!-- Modal Atualizar foto-->
<div class="modal fade" id="modal_foto" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Atualizar Foto:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="foto_form" method="POST" action="./php/atualizar_usuarios.php">
            <div class="form-group">
              <label for="novaurl">Nova URL:</label>
              <input type="url" class="form-control" id="novaurl" name="novaurl" aria-describedby="" placeholder="nova url">
              <input type="hidden" class="form-control" name="id_pessoa" aria-describedby="" value="<?php echo $id; ?>">
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" onclick="document.getElementById('foto_form').submit();">Atualizar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal Atualizar foto-->

<!-- Modal Atualiza nome-->
<div class="modal fade" id="modal_nome" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Atualizar Nome:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="nome_form" method="POST" action="./php/atualizar_usuarios.php">
            <div class="form-group">
              <label for="novonome">Nome Atual: (<?php echo $nome;?>)</label>
              <input type="text" class="form-control" id="novonome" name="novonome" aria-describedby="" placeholder="novo nome">
              <input type="hidden" class="form-control" name="id_pessoa" aria-describedby="" value="<?php echo $id; ?>">
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" onclick="document.getElementById('nome_form').submit();">Atualizar</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal Atualiza nome-->
<!-- Modal Atualiza email-->
<div class="modal fade" id="modal_email" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Atualizar Email:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="email_form" method="POST" action="./php/atualizar_usuarios.php">
            <div class="form-group">
              <label for="novoemail">Email Atual: (<?php echo $email;?>)</label>
              <input type="email" class="form-control" id="novoemail" name="novoemail" aria-describedby="" placeholder="novo email">
              <input type="hidden" class="form-control" name="id_pessoa" aria-describedby="" value="<?php echo $id; ?>">
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" onclick="document.getElementById('email_form').submit();">Atualizar</button>
      </div>
    </div>
  </div>
</div>
<!---------------------------- Modal Atualiza tipo------------------------>
<!-- Modal Atualiza-->
<div class="modal fade" id="modal_tipo" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Atualizar Tipo:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="tipo_form" method="POST" action="./php/atualizar_usuarios.php">
            <div class="form-group">
                <label for="tipo">Tipo Atual: (<?php echo $tipo;?>)</label>
                  <select class="form-control" id="tipo" name="novo_tipo">
                      <option>Aluno</option>
                      <option>Professor</option>
                      <option>Outros</option>
                  </select>
              <input type="hidden" class="form-control" name="id_pessoa" aria-describedby="" value="<?php echo $id; ?>">
            </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="button" class="btn btn-primary" onclick="document.getElementById('tipo_form').submit();">Atualizar</button>
      </div>
    </div>
  </div>
</div>
<!---------------------------- Modal Atualiza tipo------------------------>
<!---------------------------- Modal Atualiza Senha------------------------>
<!-- Modal Atualiza-->
<div class="modal fade" id="modal_senha" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Atualizar Senha:</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="nova_senha_form" method="POST" action="">
            <div class="form-group">
              <label for="senha_atual">Senha Atual: </label>
              <input type="password" class="form-control" id="senha_atual" name="senha_atual" aria-describedby="" placeholder="********" required>
              <label for="nova_senha">Nova Senha: </label>
              <input type="password" class="form-control" id="nova_senha" name="nova_senha" aria-describedby="" placeholder="********" required>
              <label for="confirme_nova_senha">Confirme Nova Senha: </label>
              <input type="password" class="form-control" id="confirme_nova_senha" name="confirme_nova_senha" aria-describedby="" placeholder="********" required>
            </div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
        <button type="submit" class="btn btn-primary" onclick="validarsenha()">Atualizar</button>
      </div>
      </form>
    </div>
  </div>
</div>
<!---------------------------- Modal Atualiza Senha------------------------>
<!-- modals -->
      <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card" style="margin-top: 1rem;">
                    <div class="card-header" style="display: flex; justify-content: center;">
                      <h5 class="card-title"> Meus Dados</h5>
                    </div>
                    <div class="card-body">
                        <img src="<?php echo $foto; ?>" class="card-img-top <?php echo $class; ?>" style="width: 10rem;"> 
                        <i class="user-name"><a href="#" data-bs-toggle="modal" data-bs-target="#modal_foto">Foto
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
                              </svg>
                            </a>
                        </i>
                        
                        <p class="card-text"> 
                            <h5>Nome Completo:<a href="#" data-bs-toggle="modal" data-bs-target="#modal_nome"><?php echo $nome; ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                    <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
                                  </svg>
                                  </a>
                            </h5>
                            </p>

                    <p class="card-text"> 
                    <h5>email: <a href="#" data-bs-toggle="modal" data-bs-target="#modal_email"><?php echo $email; ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                            <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
                          </svg>
                          </a>
                    </h5>
                    </p>
                    <p class="card-text"> 
                        <h5>Tipo de Usuário: <a href="#" data-bs-toggle="modal" data-bs-target="#modal_tipo"><?php echo $tipo; ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil" viewBox="0 0 16 16">
                                <path d="M12.146.146a.5.5 0 0 1 .708 0l3 3a.5.5 0 0 1 0 .708l-10 10a.5.5 0 0 1-.168.11l-5 2a.5.5 0 0 1-.65-.65l2-5a.5.5 0 0 1 .11-.168zM11.207 2.5 13.5 4.793 14.793 3.5 12.5 1.207zm1.586 3L10.5 3.207 4 9.707V10h.5a.5.5 0 0 1 .5.5v.5h.5a.5.5 0 0 1 .5.5v.5h.293zm-9.761 5.175-.106.106-1.528 3.821 3.821-1.528.106-.106A.5.5 0 0 1 5 12.5V12h-.5a.5.5 0 0 1-.5-.5V11h-.5a.5.5 0 0 1-.468-.325"/>
                              </svg>
                            </a>
                        </h5>
                        </p>
                    <a href="#" class="btn btn-primary" style="float: right;margin-left: 1.2rem;" data-bs-toggle="modal" data-bs-target="#modal_senha">Alterar Senha</a>
                    </div>
                </div>
            </div>
        </div>
      </div>
      <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="https://assets.locaweb.com.br/locastyle/3.10.1/javascripts/locastyle.js" type="text/javascript"></script>
     <script>
        var senha = document.getElementById("nova_senha")
        var confirme_senha = document.getElementById("confirme_nova_senha");

        function validarsenha(){
            if(senha.value != confirme_senha.value && senha.value !=null) {
                confirme_senha.setCustomValidity("As senhas não conferem!");
            } else {
                confirme_senha.setCustomValidity('');
            }
            }
        senha.onchange = validarsenha;
        confirme_senha.onkeyup = validarsenha;  
        </script>
    <?php
      if(isset($_POST['nova_senha']) && isset($_POST['senha_atual']) && isset($_POST['confirme_nova_senha']) && !empty($_POST['confirme_nova_senha']) && !empty($_POST['nova_senha']) && !empty($_POST['senha_atual'])){
            if (password_verify($_POST['senha_atual'], $user_result3['senha'])) {
              echo "senhas validas";
              $nova_senha = password_hash($_POST['nova_senha'],  PASSWORD_BCRYPT);
                try{
                        $sql01 = "UPDATE usuarios_biblioteca SET senha=? WHERE email=?";
                        $result012 = $conectdb->prepare($sql01)->execute([$nova_senha, $email]);
                            if($result012){echo "Sucesso na atualização";}
                  }catch(e){ 
                    echo "erro na atualização";
                    }
            }else{ echo "<script>alert('Senha Antiga Incorreta!');</script>";}
      }
    ?>
</body>
</html>