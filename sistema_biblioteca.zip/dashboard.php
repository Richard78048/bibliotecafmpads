<?php 
include './php/verifica_login_ativo.php';
include './php/auto_delete_historico.php';
?>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/css.css?v1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
    <script src="./js/pesquisar_livro.jsp"></script>
    <title>Biblioteca FMP ADS</title>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <a class="navbar-brand" href="dashboard.php">Biblioteca FMP ADS</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarNavDropdown" style="justify-content: center;">
            <ul class="navbar-nav">
            <form id="form" method="POST">
              <li class="nav-item">
                        <div class="input-group">
                            <input type="text" class="form-control" size="80%" placeholder="Pesquisar" name="pesquisar" id="pesquisar" aria-label="Input group example" aria-describedby="basic-addon1">
                            <span class="input-group-text" id="basic-addon1"> 
                            <button type="submit" style="background:none; border:none;">   
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                                <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001q.044.06.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1 1 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0"></path>
                            </svg>
                            </button>
                            </span>
                            
                        </div>
              </li>
              </form>
              <li class="nav-item dropdown" style="margin-left: 20% ;">
                <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                  <?php echo $_SESSION['nome']; ?>
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                    <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6"/>
                  </svg>
                </a>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="dados_pessoais.php">Dados Pessoais</a></li>
                  <?php
                  if($_SESSION['nivel'] === 'administrador') {
                  echo '<li><a class="dropdown-item" href="publicar_livro.php">Publicar</a></li>'; 
                  }
                  ?>
                  <li><a class="dropdown-item" href="historico.php">Histórico</a></li>
                  <li><a class="dropdown-item" href="./php/sair.php?sair=sim">Sair</a></li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      <div class="ls-box-filter">
        <form action="" method="post" id="form_filter" class="ls-form ls-form-inline ls">
          <label class="ls-label col-md-8 col-sm-8">
            <b class="ls-label-text">Gênero/categoria</b>
            <div class="ls-custom-select">
              <select name="pesquisar_filtro" id="nome_filter" class="ls-select">
                <option>Todos</option>
                <option>Ads</option>
                <option>Pedagogia</option>
                <option>Administração</option>
                <option>Processos</option>
                <option>Literatura</option>
                <option>Idiomas</option>
                <option>Outros</option>
              </select>
            </div>
          </label>
          <label class="ls-label" role="search">
            <span id="new_feature_custom_filter_3" data-ls-module="popover" data-content=""></span>
            <input type="text" name="ano" class="" placeholder="Ano de Publicação" id="ano">
          </label>
          <div class="ls-actions-btn" style="vertical-align: top;">
            <input type="submit" value="Filtrar" name="btn_filtrar" class="ls-btn" title="Filtrar">
          </div>
        </form>
      </div>

      <div class="container-fluid" style="background:transparent;"  id="resultado">
      <?php
      $page=1;
      if(isset($_GET['page'])){
        $page = $_GET['page'];
        if($page<1){ $page = 1;}
      }else{ $page=1;}
        
      $limit=10;
      $inicio = ($page*$limit) -$limit;
      
      if(isset($_POST['btn_filtrar']) && !empty($_POST['btn_filtrar'])){
         include './php/pesquisar_filtro.php'; 
        }else{
          include './php/pesquisar_livro.php'; 
        }
      ?>                    
        </div>
           
      </div>
      <hr>
      <?php 
      if(!isset($no)){
        $no = 'auto';
      }
        ?>
      <div class="ls-pagination-filter" style="display:<?php echo $no;?>;background:white;padding-left:3%;padding-right:3%;">
        <ul class="ls-pagination">

          <li><a href="?page=<?php echo $page-1; ?>">&laquo; Anterior</a></li>
          <?php
          $page_t = ceil($loop/$limit);
          if(isset($page_t)){
                    for ($x = 1; $x < $page_t; $x++) {
                      echo '<li><a href="?page='.$x.'">'.$x.'</a></li>';
                    }
                }
                $page_to = $page_t-1;
                if($page_to <= $page){ 
                  $page = $page_to;
                  echo '<li><a href="?page='.$page.'">Próximo &raquo;</a></li>';
                }else{ $page = $page+1; echo '<li><a href="?page='.$page.'">Próximo &raquo;</a></li>';}
          ?>
        </ul>
      </div>
    <script src="https://assets.locaweb.com.br/locastyle/3.10.1/javascripts/locastyle.js" type="text/javascript"></script>
</body>
</html>