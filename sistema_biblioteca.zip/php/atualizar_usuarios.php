<?php
include 'verifica_login_ativo.php';
include 'sql.php';
$id = $_SESSION['id'];
//variaveis
//nome 
if(isset($_POST['novonome']) && !empty($_POST['novonome'])){
    $novo_nome = $_POST['novonome'];
    try{
        $sql = "UPDATE usuarios_biblioteca SET nome=? WHERE id=?";
		$conectdb->prepare($sql)->execute([$novo_nome, $id]);
    }catch(e){ echo "erro, atualização Falhou!";}
    header('location: ../dados_pessoais.php');
}
//email
if(isset($_POST['novoemail']) && !empty($_POST['novoemail'])){
    $novo_email = $_POST ['novoemail'];
    try{
        $sql = "UPDATE usuarios_biblioteca SET email=? WHERE id=?";
		$conectdb->prepare($sql)->execute([$novo_email, $id]);
    }catch(e){ echo "erro, atualização Falhou!";}
        header('location: ../dados_pessoais.php');
}
//tipo
if(isset($_POST['novo_tipo']) && !empty($_POST['novo_tipo'])){
    $novo_tipo = $_POST ['novo_tipo'];
    try{
        $sql = "UPDATE usuarios_biblioteca SET tipo=? WHERE id=?";
		$conectdb->prepare($sql)->execute([$novo_tipo, $id]);
    }catch(e){ echo "erro, atualização Falhou!";}
        header('location: ../dados_pessoais.php');
}
//Foto Perfil
if(isset($_POST['novaurl']) && !empty($_POST['novaurl'])){
    $nova_foto = $_POST ['novaurl'];
    try{
        $sql = "UPDATE usuarios_biblioteca SET foto_url=? WHERE id=?";
		$conectdb->prepare($sql)->execute([$nova_foto, $id]);
    }catch(e){ echo "erro, atualização Falhou!";}
        header('location: ../dados_pessoais.php');
}
//variaveis 

?>