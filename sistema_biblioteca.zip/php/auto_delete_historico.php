<?php 
include 'sql.php';
if(isset($_SESSION['id'])){
$usuario = $_SESSION['id'];
$selectdb_hist1 = $conectdb -> prepare("SELECT * FROM historico_biblioteca WHERE id_user ='$usuario' ORDER BY data_acesso ASC");
                        $selectdb_hist1 -> execute();
                        $retorno_hist1 = $selectdb_hist1 -> fetchAll(PDO::FETCH_ASSOC);

                    foreach ($retorno_hist1 as $hist_r) {
                        $livro = $hist_r['id_livro'];
                        $data_expira = $hist_r['data_acesso'];
                        $date_a = date("Y/m/d");
                        if(date("Y/m/d", strtotime($date_a))>date("Y/m/d", strtotime($data_expira))){
                            $diferenca= date("d", strtotime($date_a)) - date("d", strtotime($data_expira));
                            if($diferenca >= 7){ //uma semana apague o historico
                                $tarefaMNT7 = $conectdb->query("DELETE FROM historico_biblioteca WHERE id_user='$usuario' && id_livro='$livro' ");
                            }
                            }
                        
                    }
}
    ?>