<?php
require 'sql.php';

$tarefa01 = $conectdb->query("SELECT * FROM  usuarios_biblioteca WHERE email='$email'");
    $user_result = $tarefa01->fetch();

   if ($user_result> 0) {
       //header('location:index.php?erro=Usuário já cadastrado');
       echo "<div class='flex-div'><h1>Usuário já cadastrado<br>
       <a href='../dashboard.php'>voltar ao inicio</a></h1>
       </div>";
       $cadastro = 1;
      }else{
      $cadastro = 0;
      }

?>