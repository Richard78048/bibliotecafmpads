<?php
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set('America/Sao_Paulo');

if(isset($_POST['cadastrar'])&& !empty($_POST['cadastrar'])){
    require 'sql.php';

echo "entrou em cadastrar";

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha=$_POST['senha'];
$options = [
    'cost' => 8,
];
$senha = password_hash($senha,  PASSWORD_BCRYPT, $options);

$tipo=$_POST['tipo'];
include_once 'ja_tem_cadastro.php';
if ($cadastro ==0){
   $inserir = $conectdb->prepare("INSERT INTO usuarios_biblioteca(nome, email, tipo, senha) VALUES (:nome, :email, :tipo, :senha)");

    $inserir->bindParam(':nome', $nome, PDO::PARAM_STR, 100);
    $inserir->bindParam(':email', $email, PDO::PARAM_STR, 250);
    $inserir->bindParam(':tipo', $tipo, PDO::PARAM_STR, 20);
    $inserir->bindParam(':senha', $senha, PDO::PARAM_STR, 200);

    if($inserir->execute()){
        header('location:../index.php');
        }
}
if($cadastro == 1){
    header('location:../index.php?erro=C0J1');
}
 
}
?>