 <?php
 include 'sql.php';
 $selectdb_coment = $conectdb -> prepare("SELECT * FROM comentarios_livros WHERE cod_livro ='$livro' ORDER BY data_publicacao DESC");
	$selectdb_coment -> execute();
	$retorno_comentario = $selectdb_coment -> fetchAll(PDO::FETCH_ASSOC);
    $i = 0;
	$loop = 0;
foreach ($retorno_comentario as $comentarios) {
    //pegar nome
    $id_usuario_comentou = $comentarios['id_user'];
    $data_comentario = $comentarios['data_publicacao'];
    $data_comentario = date('d/m/Y H:i', strtotime($data_comentario));
    $tarefa04 = $conectdb->query("SELECT * FROM  usuarios_biblioteca WHERE id='$id_usuario_comentou'"); //&& senha='$senha'
    $user_result04 = $tarefa04->fetch();

   if ($user_result04> 0) {
    $nome_comentou = $user_result04['nome'];
   }
   if(empty($user_result04['nome'])){ $nome_comentou = 'anonimo';} //conta apagada
    //pegar nome
    $stars = $comentarios['stars'];
    $st1 = null;
    $st2 = null;
    $st3 = null;
    $st4 = null;
    $st5 = null;
    if($stars ==1){
        $st1 = "checked";
    }
    if($stars ==2){
        $st2 = "checked";
    }
    if($stars ==3){
        $st3 = "checked";
    }
    if($stars ==4){
        $st4 = "checked";
    }
    if($stars ==5){
        $st5 = "checked";
    }
    $i = $i+1;
    
  $u='';
    if($id_usuario_comentou==$_SESSION['id']){
        $u= '
        <a href="./php/delete_coment.php?cod_livro='.$livro.'" class="btn" title="Apagar">
        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-trash" viewBox="0 0 16 16">
            <path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/>
            <path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/>
        </svg>
        </a>
        ';
    }  
  echo'
  
                    <div class="card-body" style="border-bottom:1px dotted silver;">
                        <p>
                            <img src="./img/user.png" class="card-img-top" style="width: 3rem;"> <i>'.$nome_comentou.'</i> <i style="font-size:0.65rem;">'.$data_comentario.'</i>'.$u.'
                            <div class="estrelas">
                        <label for="cm_star-1'.$i.'"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-1'.$i.'" name="stars1'.$i.'" value="1"'.$st1.' />
                        <label for="cm_star-2'.$i.'"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-2'.$i.'" name="stars1'.$i.'" value="2" '.$st2.'/>
                        <label for="cm_star-3'.$i.'"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-3'.$i.'" name="stars1'.$i.'" value="3" '.$st3.'/>
                        <label for="cm_star-4'.$i.'"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-4'.$i.'" name="stars1'.$i.'" value="4" '.$st4.'/>
                        <label for="cm_star-5'.$i.'"><i class="fa"></i></label>
                        <input type="radio" id="cm_star-5'.$i.'" name="stars1'.$i.'" value="5" '.$st5.'/>
                        </div>
                        </p>
                      <p class="card-text">'.$comentarios['comentario'].'</p>
                    </div>
                   '; 
$loop =$loop+1;
}
?>