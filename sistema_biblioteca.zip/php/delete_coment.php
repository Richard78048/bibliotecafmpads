<?php
session_start();
include_once('sql.php');

if(isset($_GET['cod_livro'])&& isset($_SESSION['id'])){
$usuario = $_SESSION['id'];
$livro = $_GET['cod_livro'];
$tarefaMNT7 = $conectdb->query("DELETE FROM comentarios_livros WHERE id_user='$usuario' && cod_livro='$livro' ");
if($tarefaMNT7){ header('location:../detalhes_livros.php?cod_livro='.$livro.'&&erro=CMD1');}
}

?>