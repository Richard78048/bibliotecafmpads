 <?php
 session_start();
include 'sql.php';
$options = [
        'cost' => 8,
        ];
if(isset($_SESSION['user']) && isset($_SESSION['senha'])){
  header('location:../dashboard.php');
}

 if(isset($_POST['mudar_senha']) && !empty($_POST['mudar_senha']) ){
    $email_v = $_SESSION['email_valida'];
    $code_v = $_SESSION['cod_valida'];
    if (strlen($_POST['nova_senha']) < 8){
        echo "<script> alert('Senha deve ter no Minimo 8 caracteres!!!'); 
        history.back();
        </script>";
    }else{
        $nova_senha = $_POST['nova_senha'];
        
        $nova_senha = password_hash($nova_senha,  PASSWORD_BCRYPT);

          try{
        $sql = "UPDATE usuarios_biblioteca SET senha=? WHERE email=? && cod_operation=?";
		$result = $conectdb->prepare($sql)->execute([$nova_senha, $email_v, $code_v]);
            if($result){
                echo "sucesso";
                $up_temp = "UPDATE usuarios_biblioteca SET cod_operation=?, data_operation_exp=? WHERE email=?";
		        $zerou = $conectdb->prepare($up_temp)->execute([null, null, $email_v]);
                        if($zerou){
                            session_destroy();
                            header('location:../index.php?erro=SA11'); //SENHA ALTERADA
                        }
            }else{ echo "falha";}

        }catch(e){ echo "erro, atualização Falhou!";}
    }
    }else{
        echo "<script> alert('Erro tente Novamente!!!'); 
        history.back();
        </script>";
    }
?>