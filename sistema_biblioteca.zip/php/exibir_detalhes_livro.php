 <?php
 include 'sql.php';
 $livro = $_GET['cod_livro'];
 $selectdb = $conectdb -> prepare("SELECT * FROM livros WHERE cod_livro ='$livro'");
	$selectdb -> execute();
	$retorno_linhas = $selectdb -> fetchAll(PDO::FETCH_ASSOC);

	$loop = 0;
foreach ($retorno_linhas as $row) {

  echo'
  <div class="card" style="margin-top: 1rem;">
                <div class="card-header" style="display: flex; justify-content: space-between;">
                  <h5 class="card-title">'.$row['titulo'].'</h5>
                  <p class="publicado">Publicado em:'.$row['data_publicacao'].'</p>
                </div>
                <div class="card-body">
                <img class="card-img-left" style="float: left; width:150px; padding:inherit !important;" src="'.$row['url_capa'].'" alt="Imagem de capa">
                <p class="card-text" style="display: -webkit-box;
                -webkit-line-clamp: 3; /** número de linhas que você quer exibir */
                -webkit-box-orient: vertical;
                overflow: hidden;
                text-overflow: ellipsis; ">'.$row['descricao'].'</p>
                <p class="card-text"> 
                Autor: '.$row['autor'].'<br>
                Editora:'.$row['editora'].'<br>
                Gênero: '.$row['genero'].'</p>
                <a href="detalhes_livros.php?cod_livro='.$row['cod_livro'].'" class="btn btn-primary" style="float: right;">Mais Informações</a>
                </div>
                   '; 
$loop =$loop+1;
}
?>