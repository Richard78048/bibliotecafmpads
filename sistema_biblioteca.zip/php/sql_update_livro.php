<?php
session_start();
include 'sql.php';
$nivel = $_SESSION['nivel'];
//variaveis
//nome
if ((!empty($_POST['cod_livro'])) && ($_SESSION['nivel']=='administrador') && (!empty($_POST['titulo'])) && (!empty($_POST['data_publicacao'])) && (!empty($_POST['descricao'])) && (!empty($_POST['capa_url'])) && (!empty($_POST['autor'])) && (!empty($_POST['editora'])) && (!empty($_POST['genero'])) && (!empty($_POST['url_livro_pdf']))){
    $livro = $_POST['cod_livro'];
    $titulo=$_POST['titulo'];
    $data_publicacao=$_POST['data_publicacao'];
    $descricao=$_POST['descricao'];
    $url_capa=$_POST['capa_url'];
    $autor=$_POST['autor'];
    $editora=$_POST['editora'];
    $genero=$_POST['genero'];
    $url_arquivo=$_POST['url_livro_pdf'];
    echo 'acessou a area update livro';

    try{
        $sql = "UPDATE livros SET autor=?, genero=?, editora=?, titulo=?, descricao=?, url_capa=?, url_arquivo=?, data_publicacao=?  WHERE cod_livro=?";
		$conectdb->prepare($sql)->execute([$autor,$genero,$editora, $titulo, $descricao, $url_capa, $url_arquivo, $data_publicacao, $livro]);
    }catch(e){ echo "erro, atualização Falhou!";}
    header('location: ../detalhes_livros.php?cod_livro='.$livro);
}

?>