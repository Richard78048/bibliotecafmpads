<?php
header("Content-type: text/html; charset=utf-8");
date_default_timezone_set('America/Sao_Paulo');

echo "não entrou em livro";

if(isset($_POST['titulo'])&& !empty($_POST['titulo'])){
    require 'sql.php';
$titulo = $_POST['titulo'];
$data_publicacao = $_POST['data_publicacao'];
$capa_url=$_POST['capa_url'];
$genero=$_POST['genero'];
$autor=$_POST['autor'];
$editora=$_POST['editora'];
$url_livro_pdf = $_POST['url_livro_pdf'];
$descricao = $_POST['descricao'];

   $inserir = $conectdb->prepare("INSERT INTO livros(titulo, data_publicacao, url_capa, genero, autor, editora, url_arquivo, descricao) VALUES (:titulo, :data_publicacao, :url_capa, :genero, :autor, :editora, :url_livro_pdf, :descricao)");

    $inserir->bindParam(':titulo', $titulo, PDO::PARAM_STR, 150);
    $inserir->bindParam(':data_publicacao', $data_publicacao, PDO::PARAM_STR, 250);
    $inserir->bindParam(':url_capa', $capa_url, PDO::PARAM_STR, 1000);
    $inserir->bindParam(':genero', $genero, PDO::PARAM_STR, 50);
    $inserir->bindParam(':autor', $autor, PDO::PARAM_STR, 100);
    $inserir->bindParam(':editora', $editora, PDO::PARAM_STR, 100);
    $inserir->bindParam(':url_livro_pdf', $url_livro_pdf, PDO::PARAM_STR, 1000);
    $inserir->bindParam(':descricao', $descricao, PDO::PARAM_STR);

    if($inserir->execute()){
        echo"<div class='flex-div'><h1>Livro cadastrado com Sucesso</h1>
        <a href='../dashboard.php'>voltar ao inicio</a>
        </div>";
        header('location:../publicar_livro.php?erro=PB11');
        } 
}
 
?>