<?php
session_start();


if(isset($_SESSION['user']) && isset($_SESSION['senha'])){
  header('location:../dashboard.php');
}

$type ="number";
$type2 ="submit";
$type3 ="password";
  $class1 ="form_group";
    $class2 = "form-control";
    $nome_var = "cod_ver";
    $place = "código_recebido";
    $place3 = "Nova_Senha";
    $place4 = "Confirme_Senha";
    $style = "padding:0%;";
    $style2 = "margin-bottom:1.2rem;";
    $func = "verificacod()";
    $func2 = "validarsenha()";
    $size = 6;
    $class_btn="btnSubmit";
    $nome_var_btn = "ver_cod_dig";
    $value_btn = "Validar";
    $senha_var_btn = "mudar_senha";
    $value_senha_btn = "Atualizar";

    $id_senha_css = "nova_senha";
    $name_senha = "nova_senha";
    $id_confirme_senha_css = "confirme_senha";
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FMP BIBLIOTECA ADS</title>
    <link rel="stylesheet" href="../css/login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="https://assets.locaweb.com.br/locastyle/3.10.1/stylesheets/locastyle.css" rel="stylesheet" type="text/css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.4.min.js"></script>

<script>
var url_string = window.location.href;
var url = new URL(url_string);
var data = url.searchParams.get("erro"); 
if(data == 'TS00'){
    alert("Senha Curta!");
}
</script>
</head>
<body>

<div class="container login-container">
            <div class="row">
                <div class="col-md-6 login-form-1">
                    <img src="https://img.freepik.com/fotos-premium/uma-imagem-com-um-fundo-desfocado-mostra-uma-estante-de-biblioteca-com-muitos-livros-nela_410516-43749.jpg" width="100%">
                </div>
                <div class="col-md-6 login-form-2">
                    <h3>Recuperação de Senha:</h3>
                    <form method="post" action="#" id="first">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Seu Email *" name="email" id="email" required/>
                        </div>
                        <div class="form-group">
                            <input type="submit" class="btnSubmit" name="enviar_cod" value="Enviar Código" />
                        </div>
                    </form>
                    <form id="veirifica_codigo_form" method="GET">
                    <div class="form-group" id="cod" style="margin-top: 0.2rem; text-align:center;">
                        </div>
                        </form>
                    
                    <form id="form_senha" method="POST" action="update_senha.php">
                    <div class="form-group" id="senha" style="margin-top: 0.2rem; text-align:center;">
                    </div>
                    </form>    
                </div>
            </div>
        </div>
</body>
</html>
<?php
if(isset($_POST['enviar_cod']) && !empty($_POST['enviar_cod']) ){
    require 'sql.php';
    $email = trim(strip_tags($_POST['email']));

    $tarefa02 = $conectdb->query("SELECT * FROM  usuarios_biblioteca WHERE email='$email'"); //&& senha='$senha'
        $user_result2 = $tarefa02->fetch();
        $data1= date('Y-m-d H:i:s');
            if(!isset($user_result2['cod_operation']) && empty($user_result2['cod_operation'])){

        if ($user_result2> 0) {
        $data_expira = date('Y-m-d H:i:s' , time()+4600); //20 minutos depois para
        $cod_gerado = rand(100000,999999);
        
        try{
        $sql = "UPDATE usuarios_biblioteca SET cod_operation=?, data_operation_exp=? WHERE email=?";
		$conectdb->prepare($sql)->execute([$cod_gerado, $data_expira, $email]);
        }catch(e){ echo "erro, atualização Falhou!";}

		$email = $_POST['email'];
        $_SESSION['email_valida'] = $email;
        $nome = $user_result2['nome'];
		$mensagem = "Seu Codigo de Verificação para troca de senha é:"; 
  		$data_envio = date('d/m/Y');
  		$hora_envio = date('H:i:s');
      //dados servidor  
  //Emails para quem será enviado o formulário
  $destino =  $email;
  $assunto = "Recuperação de Senha Bibiblioteca Online Ads";
//Compo E-mail
  $arquivo = "
      E-mail: $email
      Assunto: $assunto
      Mensagem: $mensagem$cod_gerado
      Data de envio: $data_envio às $hora_envio hrs
  ";
  //campo de dados da mensagem

  //Este sempre deverá existir para garantir a exibição correta dos caracteres
  $headers  = "MIME-Version: 1.0\n";
  $headers .= "Content-type: text/html; charset=iso-8859-1\n";
  $headers .= "From: $nome <$email>";

  //Enviar
  try{
  mail($destino, $assunto, $arquivo, $headers);
  
  echo "<script>alert('Código Enviado!, Verifique sua caixa de entrada, spam e lixeira');
            document.getElementById('email').placeholder='".$email."';
            var novoElemento = document.createElement('div');
            novoElemento.innerHTML = '<div class=".$class1." style=".$style."><input type=".$type." class=".$class2." placeholder=".$place." name=".$nome_var." id=".$nome_var." onkeyup=".$func." maxlength=".$size." required/></div><div class=".$class1."><input type=".$type2." class=".$class_btn." name=".$nome_var_btn." value=".$value_btn." /></div>';
                document.getElementById('cod').appendChild(novoElemento);
        </script>";

  }catch(E){ 
    echo "<script type='javascript'>alert('Email Não enviado!');";
  }     
            }else{ 
                    echo "<script>alert('Email Não Cadastrado!');</script>";
                }

        } //veificar se ja solicitou
        if($user_result2['cod_operation']>100000){
            echo "<script>
            document.getElementById('email').placeholder='".$email."';
            var novoElemento = document.createElement('div');
            novoElemento.innerHTML = '<div class=".$class1." style=".$style."><input type=".$type." class=".$class2." placeholder=".$place." name=".$nome_var." id=".$nome_var." onkeyup=".$func." maxlength=".$size." required/></div><div class=".$class1."><input type=".$type2." class=".$class_btn." name=".$nome_var_btn." value=".$value_btn." /></div>';
                document.getElementById('cod').appendChild(novoElemento);
        </script>";
        }
}
if(isset($_GET['ver_cod_dig']) && !empty($_GET['ver_cod_dig']) ){
    echo "<script>
        var node = document.getElementById('first');
        if (node.parentNode) {
        node.parentNode.removeChild(node);
         var novoElemento = document.createElement('div');
            novoElemento.innerHTML = '<div class=".$class1." style=".$style."><input type=".$type." class=".$class2." placeholder=".$place." name=".$nome_var." id=".$nome_var." onkeyup=".$func." maxlength=".$size." required/></div><div class=".$class1."><input type=".$type2." class=".$class_btn." name=".$nome_var_btn." value=".$value_btn." /></div>';
            document.getElementById('veirifica_codigo_form').appendChild(novoElemento);

        }
    </script>";
    $cod_digitado = $_GET['cod_ver'];
    $email_valida = $_SESSION['email_valida'];
    include_once 'sql.php';
    $tarefa03 = $conectdb->query("SELECT * FROM  usuarios_biblioteca WHERE email='$email_valida' && cod_operation='$cod_digitado' LIMIT 1"); //&& senha='$senha'
        $user_result3 = $tarefa03->fetch();
    if(empty($user_result3)){
        echo "<script> alert('Código Inválido')</script>";
    }else{
        $_SESSION['cod_valida'] = $cod_digitado;
        $size_s = 8;
        $size_m = 16;

        echo "<script>
         var node = document.getElementById('veirifica_codigo_form');
        if (node.parentNode) {
        node.parentNode.removeChild(node);
        var novoElemento = document.createElement('div');
            novoElemento.innerHTML = '<div class=".$class1." style=".$style."><input type=".$type3." class=".$class2." placeholder=".$place3." name=".$name_senha." id=".$id_senha_css." min-length=".$size_s." max-length=".$size_m." required/><input type=".$type3." class=".$class2." placeholder=".$place4." id=".$id_confirme_senha_css." onfocus=".$func2." min-length=".$size_s." max-length=".$size_m." required/></div><div class=".$class1."><input type=".$type2." class=".$class_btn." style=".$style2." name=".$senha_var_btn." value=".$value_senha_btn." /></div>';
            document.getElementById('senha').appendChild(novoElemento);
        }
        </script>";
        echo "
         <script >
        var senha = document.getElementById('nova_senha')
        var confirme_senha = document.getElementById('confirme_senha');

        function validarsenha(){
            if(senha.value != confirme_senha.value) {
                confirme_senha.setCustomValidity('As senhas não conferem!');
            } else {
                confirme_senha.setCustomValidity('');
            }
            }
        senha.onchange = validarsenha;
        confirme_senha.onkeyup = validarsenha;  
        </script>
        ";
    }
}
?>