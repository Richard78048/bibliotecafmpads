<?php
session_start();
if($_GET['sair'] === 'sim'){
    session_destroy();
    header('location:../index.php');
}

?>