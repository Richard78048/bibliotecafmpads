<?php 

if(isset($_SESSION['id']) && (!empty($_SESSION['id']))){
$_id_user_hist = $_SESSION['id'];
$_id_livro_hist = $_GET['cod_livro'];
   $inserir = $conectdb->prepare("INSERT INTO historico_biblioteca(data_acesso, id_livro, id_user) VALUES (now(), :id_livro, :id_user)");

    $inserir->bindParam(':id_livro', $_id_livro_hist, PDO::PARAM_INT, 15);
    $inserir->bindParam(':id_user', $_id_user_hist, PDO::PARAM_INT, 15);
    if($inserir->execute()){
    }
}

    ?>