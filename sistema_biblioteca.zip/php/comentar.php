<?php
session_start();

header("Content-type: text/html; charset=utf-8");
date_default_timezone_set('America/Sao_Paulo');

echo "não entrou em comentario";
print($_POST['cod_livro']);

if(isset($_POST['cod_livro'])&& !empty($_POST['cod_livro'])){
    require 'sql.php';

echo "publicar comentario acessado";

$cod_livro = $_POST['cod_livro'];
$cod_user = $_SESSION['id'];
$stars = $_POST['stars'];
$comentario = $_POST['comentario'];
//verifica se usuario ja comentou nesse livro
$tarefa05 = $conectdb->query("SELECT * FROM  comentarios_livros WHERE id_user='$cod_user' && cod_livro='$cod_livro'");
    $coment_existe_result = $tarefa05->fetch();
   if ($coment_existe_result> 0) {
    header('location:../detalhes_livros.php?cod_livro='.$cod_livro.'&erro=CMT1');
   }else{
//verifica se usuario ja comentou nesse livro


   $inserir = $conectdb->prepare("INSERT INTO comentarios_livros(cod_livro, comentario, id_user, stars, data_publicacao) VALUES (:cod_livro, :comentario, :id_user, :stars, now())");

    $inserir->bindParam(':cod_livro', $cod_livro, PDO::PARAM_INT, 15);
    $inserir->bindParam(':comentario', $comentario, PDO::PARAM_STR, 250);
    $inserir->bindParam(':id_user', $cod_user, PDO::PARAM_INT, 15);
    $inserir->bindParam(':stars', $stars, PDO::PARAM_INT, 1);

    if($inserir->execute()){
        header('location:../detalhes_livros.php?cod_livro='.$cod_livro);
        } else{ header('location:../detalhes_livros.php?cod_livro='.$cod_livro,'&erro=CMT0');}
}
}
?>