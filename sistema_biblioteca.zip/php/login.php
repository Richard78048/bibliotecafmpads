<?php
session_start();

if(isset($_POST['login'])&& !empty($_POST['login'])){
require 'sql.php';
$email = $_POST['email'];
$senha = $_POST['senha'];

$tarefa02 = $conectdb->query("SELECT * FROM  usuarios_biblioteca WHERE email='$email' "); //&& senha='$senha'
    $user_result2 = $tarefa02->fetch();

   if ($user_result2> 0) {
    if (password_verify($senha, $user_result2['senha'])) {
    $_SESSION['id'] = $user_result2['id'];
    $_SESSION['user'] = $email;
    $_SESSION['senha'] = $senha;
    $_SESSION['nome'] = $user_result2['nome'];
    $_SESSION['nivel'] = $user_result2['nivel'];
       header('location:../dashboard.php');
} else {
    echo 'A senha é inválida.';
    header('location:../index.php?erro=S0I1');
}
    
      }else{
      header('location:../index.php?erro=0AS0');
      }
}
?>