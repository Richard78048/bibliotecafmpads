<?php
$dbhost = 'Seu DB HOST';
$dbuser = 'SEU USUARIO DB';   
$dbpassword = 'SUA SENHA';
try{
$conectdb = new PDO('mysql:host=localhost;dbname=nomedoseubanco', $dbuser, $dbpassword);
 $conectdb->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  //echo 'Conectado Com sucesso';
} catch(PDOException $e) {
    echo 'ERROR: ' . $e->getMessage();
}
?>